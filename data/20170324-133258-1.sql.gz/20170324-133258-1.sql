-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2017-03-24 13:32:58
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `mini_orders`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders`;
CREATE TABLE `mini_orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `order_no` varchar(20) NOT NULL COMMENT '订单号',
  `print_no` varchar(30) DEFAULT NULL COMMENT '小票打印机单号',
  `express_type` varchar(100) DEFAULT NULL COMMENT '快递方式',
  `express_no` varchar(100) DEFAULT NULL COMMENT '快递编号',
  `pay_type` varchar(10) NOT NULL COMMENT '支付方式',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `createtime` int(11) NOT NULL,
  `is_pay` int(11) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL COMMENT '支付状态',
  `memo` varchar(255) DEFAULT NULL COMMENT '订单备注',
  `consignee_name` varchar(100) DEFAULT NULL COMMENT '收货人',
  `address` text COMMENT '收货地址',
  `mobile` varchar(11) DEFAULT NULL COMMENT '收货人电话',
  PRIMARY KEY (`id`,`uuid`,`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders`
-- -----------------------------
INSERT INTO `mini_orders` VALUES ('73', '442ba8af-7fd7-84f6-1a30-6140f85703bd', '1', '2017032353485397', '', '', '', 'wxpay', '700.00', '1490255221', '0', 'nopaid', '', '哈哈', '北京东城区了开发的发放', '13810773215');
INSERT INTO `mini_orders` VALUES ('74', 'ae637617-0e7f-6986-f645-68edfe99cd9f', '1', '2017032456564853', '', '', '', 'wxpay', '760.00', '1490332760', '0', 'nopaid', '', '哈哈', '北京东城区了开发的发放', '13810773215');

-- -----------------------------
-- Table structure for `mini_orders_address`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_address`;
CREATE TABLE `mini_orders_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `consignee_name` varchar(100) NOT NULL COMMENT '收货人',
  `province` varchar(100) NOT NULL COMMENT '省',
  `city` varchar(100) NOT NULL COMMENT '市',
  `county` varchar(100) NOT NULL COMMENT '县/区',
  `address` text NOT NULL COMMENT '详细地址',
  `mobile` varchar(11) NOT NULL COMMENT '联系电话',
  `status` int(10) NOT NULL DEFAULT '1' COMMENT '1-正常 -1-已删除',
  `default` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为默认收货地址1-是 0-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders_address`
-- -----------------------------
INSERT INTO `mini_orders_address` VALUES ('14', '1', '哈哈', '北京', '东城区', '', '了开发的发放', '13810773215', '1', '1');

-- -----------------------------
-- Table structure for `mini_orders_goods`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_goods`;
CREATE TABLE `mini_orders_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(11) NOT NULL COMMENT '订单号',
  `goods_id` int(11) NOT NULL COMMENT '商品id',
  `name` varchar(255) NOT NULL,
  `num` int(10) NOT NULL COMMENT '购买数量',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `description` text NOT NULL,
  `standard` varchar(255) NOT NULL,
  `cover_path` varchar(255) NOT NULL,
  `is_comment` varchar(10) NOT NULL DEFAULT '-1' COMMENT '商品是否评论 -1-否  1-是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders_goods`
-- -----------------------------
INSERT INTO `mini_orders_goods` VALUES ('74', '73', '42', '红枣夹核桃', '28', '25.00', '红枣夹核桃', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '-1');
INSERT INTO `mini_orders_goods` VALUES ('75', '74', '44', '核桃仁', '1', '35.00', '核桃仁', '100克X10袋', '/uploads/picture/20161223/9da72a3997817954407982362b3ac40a.jpg', '-1');
INSERT INTO `mini_orders_goods` VALUES ('76', '74', '42', '红枣夹核桃', '29', '25.00', '红枣夹核桃', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '-1');
