-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2017-03-28 18:06:14
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `mini_apiconfig`
-- -----------------------------
DROP TABLE IF EXISTS `mini_apiconfig`;
CREATE TABLE `mini_apiconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `key` varchar(255) NOT NULL COMMENT '配置项名称',
  `value` varchar(255) NOT NULL COMMENT '配置项值',
  `description` varchar(255) DEFAULT NULL COMMENT '配置描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_apiconfig`
-- -----------------------------
INSERT INTO `mini_apiconfig` VALUES ('1', 'print_apikey', '', 'API密钥');
INSERT INTO `mini_apiconfig` VALUES ('2', 'print_machine_code', '', '打印机终端号');
INSERT INTO `mini_apiconfig` VALUES ('3', 'print_msign', '', '打印机密钥');
INSERT INTO `mini_apiconfig` VALUES ('4', 'print_mobiliphone', '', '终端内部手机号');
INSERT INTO `mini_apiconfig` VALUES ('5', 'print_partner', '', '易连云用户ID');
INSERT INTO `mini_apiconfig` VALUES ('6', 'print_username', '', '易连云用户名');
INSERT INTO `mini_apiconfig` VALUES ('7', 'print_printname', '', '打印机终端名称');
INSERT INTO `mini_apiconfig` VALUES ('8', 'sms_appkey', '', 'Key值');
INSERT INTO `mini_apiconfig` VALUES ('9', 'sms_appsecret', '', '密钥');
INSERT INTO `mini_apiconfig` VALUES ('10', 'sms_template_code', '', '模板ID');
INSERT INTO `mini_apiconfig` VALUES ('11', 'sms_signname', '', '签名名称');
INSERT INTO `mini_apiconfig` VALUES ('12', 'alipay_partner', '', '合作身份者ID，签约账号，以2088开头由16位纯数字组成的字符串');
INSERT INTO `mini_apiconfig` VALUES ('13', 'alipay_appkey', '', ' MD5密钥，安全检验码，由数字和字母组成的32位字符串');
INSERT INTO `mini_apiconfig` VALUES ('14', 'wechat_appid', '', '微信公众号身份的唯一标识');
INSERT INTO `mini_apiconfig` VALUES ('15', 'wechat_mchid', '', '受理商ID，身份标识');
INSERT INTO `mini_apiconfig` VALUES ('16', 'wechat_appkey', '', '商户支付密钥Key');
INSERT INTO `mini_apiconfig` VALUES ('17', 'wechat_appsecret', '', 'JSAPI接口中获取openid');
INSERT INTO `mini_apiconfig` VALUES ('18', 'wechat_token', '', '微信通讯token值');
INSERT INTO `mini_apiconfig` VALUES ('19', 'baidu_map_ak', '', '百度地图秘钥(ak)');
INSERT INTO `mini_apiconfig` VALUES ('20', 'baidu_map_lon', '', '中心点经度');
INSERT INTO `mini_apiconfig` VALUES ('21', 'baidu_map_lat', '', '中心点纬度');

-- -----------------------------
-- Table structure for `mini_banner`
-- -----------------------------
DROP TABLE IF EXISTS `mini_banner`;
CREATE TABLE `mini_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT '广告名称',
  `description` varchar(500) NOT NULL DEFAULT '' COMMENT '广告位置描述',
  `position` int(11) NOT NULL COMMENT '广告位置',
  `banner_path` varchar(140) NOT NULL COMMENT '图片地址',
  `link` varchar(140) NOT NULL DEFAULT '' COMMENT '连接地址',
  `level` int(4) NOT NULL DEFAULT '0' COMMENT '优先级',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（2：禁用 1：正常）',
  `createtime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- -----------------------------
-- Records of `mini_banner`
-- -----------------------------
INSERT INTO `mini_banner` VALUES ('1', 'banner图1', 'banner图1', '1', '/uploads/picture/20170228/9b77aeb9cf87e3bf1d16fbad49a8acb7.jpg', '#', '0', '1', '1474862526', '0');
INSERT INTO `mini_banner` VALUES ('2', 'banner图2', 'banner图2', '1', '/uploads/picture/20170228/ecbbf51705ef516ca5d39ae5833d0fef.jpg', '#', '0', '1', '1474862717', '0');
INSERT INTO `mini_banner` VALUES ('4', '推荐商品', '推荐商品', '2', '/uploads/picture/20161223/eb0cf5de7fcc4b8f96225a30e5f61655.png', '#', '0', '1', '1474878074', '0');
INSERT INTO `mini_banner` VALUES ('5', '首页广告图', '首页广告图', '3', '/uploads/picture/20161209/d08256b4d28db935eabe9012c7fe78a7.png', '#', '0', '1', '1478664585', '0');
INSERT INTO `mini_banner` VALUES ('6', '单页广告', '单页广告', '4', '/uploads/picture/20161223/bc7d829ba8c3e1d73a29bf7f00696e31.jpg', '#', '0', '1', '1482475484', '0');

-- -----------------------------
-- Table structure for `mini_banner_position`
-- -----------------------------
DROP TABLE IF EXISTS `mini_banner_position`;
CREATE TABLE `mini_banner_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` char(80) NOT NULL,
  `width` char(20) NOT NULL,
  `height` char(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用 1：正常)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_banner_position`
-- -----------------------------
INSERT INTO `mini_banner_position` VALUES ('1', 'pc首页banner图', '1200', '300', '1');
INSERT INTO `mini_banner_position` VALUES ('2', '商品页推荐', '200', '260', '1');
INSERT INTO `mini_banner_position` VALUES ('3', 'wap首页焦点图', '', '', '1');
INSERT INTO `mini_banner_position` VALUES ('4', 'pc端单页广告', '1200', '139', '1');

-- -----------------------------
-- Table structure for `mini_business_need`
-- -----------------------------
DROP TABLE IF EXISTS `mini_business_need`;
CREATE TABLE `mini_business_need` (
  `name` char(128) NOT NULL COMMENT '姓名',
  `mobile` varchar(128) NOT NULL COMMENT '手机号',
  `wx` char(128) DEFAULT NULL COMMENT '微信号',
  `description` text COMMENT '备注',
  `createtime` int(11) NOT NULL,
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_business_need`
-- -----------------------------
INSERT INTO `mini_business_need` VALUES ('111111111', '2147483647', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('11111111', '2147483647', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('11111111', '2147483647', '', '', '0');

-- -----------------------------
-- Table structure for `mini_cart`
-- -----------------------------
DROP TABLE IF EXISTS `mini_cart`;
CREATE TABLE `mini_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '购买数量',
  `createtime` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1：正常，2：已购买',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_cart`
-- -----------------------------
INSERT INTO `mini_cart` VALUES ('56', '1', '45', '1', '1487299145', '1');

-- -----------------------------
-- Table structure for `mini_code`
-- -----------------------------
DROP TABLE IF EXISTS `mini_code`;
CREATE TABLE `mini_code` (
  `id` int(60) NOT NULL AUTO_INCREMENT,
  `mobile` char(128) DEFAULT NULL,
  `code` char(30) DEFAULT NULL,
  `yzm_time` int(60) DEFAULT NULL,
  `num` int(60) NOT NULL DEFAULT '0',
  `captcha` char(30) NOT NULL,
  `date` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_email_check`
-- -----------------------------
DROP TABLE IF EXISTS `mini_email_check`;
CREATE TABLE `mini_email_check` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `username` char(128) NOT NULL,
  `email` char(128) NOT NULL,
  `passtime` int(128) NOT NULL,
  `token` char(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_goods`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods`;
CREATE TABLE `mini_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT '商品名称',
  `num` int(11) NOT NULL COMMENT '商品库存数量',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `description` text NOT NULL COMMENT '商品描述',
  `man_profiles` text NOT NULL COMMENT '达人个人简介',
  `goods_profiles` text NOT NULL COMMENT '达人体验简介',
  `standard` varchar(255) NOT NULL COMMENT '规格型号',
  `cover_path` varchar(255) NOT NULL COMMENT '封面图',
  `photo_path_1` varchar(255) DEFAULT NULL,
  `photo_path_2` varchar(255) DEFAULT NULL,
  `photo_path_3` varchar(255) DEFAULT NULL,
  `content` text NOT NULL COMMENT '商品详情',
  `click_count` int(11) NOT NULL DEFAULT '0' COMMENT '商品点击数',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:上架，2：下架',
  `is_best` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为精品',
  `is_new` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为新品',
  `is_hot` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为热销',
  `sell_num` int(11) NOT NULL DEFAULT '0' COMMENT '已经出售的数量',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `score_num` tinyint(2) NOT NULL DEFAULT '1' COMMENT '平均评分',
  `score` int(11) DEFAULT NULL COMMENT '积分',
  `label_tese` text NOT NULL COMMENT '特色标签',
  `label_quan` text NOT NULL COMMENT '券代标签',
  `label_area` text NOT NULL COMMENT '地区标签',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_goods`
-- -----------------------------
INSERT INTO `mini_goods` VALUES ('42', '1', '53a769cc-a891-ad3e-4eb5-5547c5c26501', '红枣夹核桃', '850', '25.00', '红枣夹核桃', '', '', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '/uploads/picture/20161223/8ebcd35d834e8fd1a69551aa6c0b2a0e.jpg', '', '', '<p><img src="/minishop/uploads/editor/image/20161223/1482462323832580.jpg" title="1482462323832580.jpg" alt="1478826260676720.jpg"/></p>', '3652', '1', '0', '0', '0', '201', '1482462498', '1', '10', '', '', '');
INSERT INTO `mini_goods` VALUES ('43', '1', '33070903-41f6-ede2-eeac-275adad0e25e', '柴鸡蛋', '9999', '55.00', '柴鸡蛋', '', '', '45枚', '/uploads/picture/20161223/5392df9916f3ab0da1e791543232825c.jpg', '/uploads/picture/20161223/087927f3e9c8efaeb51cc8b79e7c99eb.jpg', '', '', '<p><img src="/minishop/uploads/editor/image/20161223/1482462604190277.jpg" title="1482462604190277.jpg" alt="1478826113596298.jpg"/></p>', '665', '1', '1', '0', '0', '3251', '1490677169', '1', '50', '', '', '');
INSERT INTO `mini_goods` VALUES ('44', '1', 'db49d2e5-3626-3a32-8ad0-0f8c826358b7', '核桃仁', '100', '35.00', '核桃仁', '', '', '100克X10袋', '/uploads/picture/20161223/9da72a3997817954407982362b3ac40a.jpg', '/uploads/picture/20161223/d1609a657d1c3ff75c2e5fe85d0d7ffc.jpg', '', '', '<p><img src="/minishop/uploads/editor/image/20161223/1482463174435180.jpg" title="1482463174435180.jpg" alt="1478826044199317.jpg"/></p>', '664', '1', '0', '0', '0', '211', '1482463214', '1', '20', '', '', '');
INSERT INTO `mini_goods` VALUES ('45', '1', '8f4d7948-5e0a-e9ba-e390-cb1ddc9f951f', '大坚果（测试）', '100', '0.01', '大坚果（测试）', '', '', '9999', '/uploads/picture/20170328/a0ce53233c5ea40ec4d0a8d6870fa9c2.jpg', '/uploads/picture/20161223/0e3ee9c8c961131268bcd93f3f350585.jpg', '', '', '<p><img src="/minishop/uploads/editor/image/20161223/1482463362407897.jpg" title="1482463362407897.jpg" alt="bf3561f1c4ccab5b0ffd1fa705ee61e5-600x600.jpg"/></p>', '9999', '1', '1', '0', '0', '9999', '1490675164', '1', '9999', '', '', '');
INSERT INTO `mini_goods` VALUES ('46', '1', '8405877c-ffa8-072a-1dfd-d5dd17a27b6b', '沾化冬枣', '100', '58.00', '沾化冬枣', '', '', '58元/5斤', '/uploads/picture/20161223/92b1e19825fd56dae606e1589d567647.jpg', '/uploads/picture/20161223/af0ebd0ec71dea809f35b3550fe11abe.jpg', '', '', '<p><img src="/minishop/uploads/editor/image/20161223/1482463513645507.jpg" title="1482463513645507.jpg" alt="T1zr6HFaJbXXb1upjX.jpg"/></p>', '364', '1', '1', '1', '1', '55', '1490692486', '1', '58', '', '', '');
INSERT INTO `mini_goods` VALUES ('47', '1', 'a91b6769-6a4c-f41c-fc7b-d01d84b50e89', '陕西冬枣', '100', '36.00', '陕西冬枣', '', '', '36元/6斤', '/uploads/picture/20161223/7a0174fd13aa36fa5abc6870a81518d1.jpg', '/uploads/picture/20161223/f728b1267d15460044489b62916aff62.jpg', '', '', '<p style="text-align: center;"><img src="http://api.map.baidu.com/staticimage?center=116.404,39.915&zoom=10&width=980&height=610&markers=116.404,39.915"/></p>', '5741', '1', '1', '1', '1', '998', '1490677901', '1', '18', '北极光|破冰船', '券|代', '东京');
INSERT INTO `mini_goods` VALUES ('48', '1', '1600f4f8-b58f-883d-cc73-82ffa3c7eba9', '佳宝话梅', '654', '12.00', '佳宝话梅', '', '', '1袋', '/uploads/picture/20161223/ce0d6b0736a45cae2d86ac5385022bfb.jpg', '/uploads/picture/20161223/b28dc4a79e9eea639ed24b4a2a3cac1f.jpg', '', '', '<p><img src="/minishop/uploads/editor/image/20161223/1482464226453521.jpg" title="1482464226453521.jpg" alt="4919586_200740644371_2.jpg"/></p>', '684', '1', '1', '1', '1', '341', '1490673271', '1', '12', '', '', '');

-- -----------------------------
-- Table structure for `mini_goods_cate`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_cate`;
CREATE TABLE `mini_goods_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL COMMENT '分类名',
  `slug` varchar(200) NOT NULL COMMENT '缩略名',
  `cover_path` varchar(200) NOT NULL COMMENT '分类封面图',
  `pid` int(11) NOT NULL DEFAULT '0',
  `page_num` int(11) NOT NULL,
  `lists_tpl` varchar(200) NOT NULL,
  `detail_tpl` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:启用，2：禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_goods_cate`
-- -----------------------------
INSERT INTO `mini_goods_cate` VALUES ('1', '零食', 'lingshi', '/uploads/picture/20160926/44bfb87ac0b9e57bd44d42f178b3a714.png', '0', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('3', '水果', 'fruit', '/uploads/picture/20160926/ebdc0529dc755654a2dd845cd8eb3d3a.png', '0', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('5', '土特产品', 'local', '/uploads/picture/20161223/5f2fb30b32f2983cc262f2e51e67bc0f.jpg', '0', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('9', '大枣', 'chinese-date', '/uploads/picture/20161111/4651a796acc28389e763287e89f337f7.jpg', '5', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('19', '干果', 'dried fruit', '/uploads/picture/20161111/a6041921202f830ff9e27e0e807634f9.jpg', '1', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('20', '冬枣', 'dongzao', '', '3', '1', 'goods_qingdingzhi', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('21', '鸡蛋', 'eggs', '', '5', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('22', '核桃仁', 'semen-juglandis', '', '5', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('23', '话梅', 'preserved-plum', '', '3', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('24', '1', '1-1', '', '0', '20', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('25', '轻定制', 'qdz', '', '0', '20', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('26', '亲途达人', 'qtdr', '', '0', '20', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('27', '主题定制', 'ztdz', '', '0', '20', 'goods_ztdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('28', '全部', 'qdz_area_all', '', '30', '20', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('29', '北海道', 'qdz_area_bhd', '', '30', '20', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('30', '地区', 'qdz_area', '', '25', '20', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('32', '特色', 'qdz_tese', '', '25', '20', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('33', '全部', 'qdz_tese_all', '', '32', '1', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('34', '地区', 'qtdr_area', '', '26', '20', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('35', '全部', 'qtdr_area_all', '', '34', '20', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('36', '特色', 'qtdr_tese', '', '26', '20', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('37', '全部', 'qtdr_tese_all', '', '36', '20', 'goods_qtdr_list', 'goods_detail', '1');

-- -----------------------------
-- Table structure for `mini_goods_cate_relationships`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_cate_relationships`;
CREATE TABLE `mini_goods_cate_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `cate_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_goods_cate_relationships`
-- -----------------------------
INSERT INTO `mini_goods_cate_relationships` VALUES ('1', '1', '2');
INSERT INTO `mini_goods_cate_relationships` VALUES ('4', '2', '2');
INSERT INTO `mini_goods_cate_relationships` VALUES ('8', '5', '5');
INSERT INTO `mini_goods_cate_relationships` VALUES ('10', '3', '4');
INSERT INTO `mini_goods_cate_relationships` VALUES ('82', '10', '12');
INSERT INTO `mini_goods_cate_relationships` VALUES ('83', '8', '8');
INSERT INTO `mini_goods_cate_relationships` VALUES ('85', '4', '7');
INSERT INTO `mini_goods_cate_relationships` VALUES ('86', '21', '10');
INSERT INTO `mini_goods_cate_relationships` VALUES ('87', '7', '11');
INSERT INTO `mini_goods_cate_relationships` VALUES ('89', '25', '7');
INSERT INTO `mini_goods_cate_relationships` VALUES ('91', '15', '8');
INSERT INTO `mini_goods_cate_relationships` VALUES ('92', '17', '12');
INSERT INTO `mini_goods_cate_relationships` VALUES ('93', '14', '13');
INSERT INTO `mini_goods_cate_relationships` VALUES ('94', '18', '15');
INSERT INTO `mini_goods_cate_relationships` VALUES ('95', '12', '17');
INSERT INTO `mini_goods_cate_relationships` VALUES ('96', '13', '16');
INSERT INTO `mini_goods_cate_relationships` VALUES ('97', '20', '16');
INSERT INTO `mini_goods_cate_relationships` VALUES ('98', '23', '15');
INSERT INTO `mini_goods_cate_relationships` VALUES ('99', '27', '6');
INSERT INTO `mini_goods_cate_relationships` VALUES ('100', '26', '8');
INSERT INTO `mini_goods_cate_relationships` VALUES ('101', '11', '13');
INSERT INTO `mini_goods_cate_relationships` VALUES ('102', '9', '10');
INSERT INTO `mini_goods_cate_relationships` VALUES ('104', '19', '8');
INSERT INTO `mini_goods_cate_relationships` VALUES ('105', '22', '8');
INSERT INTO `mini_goods_cate_relationships` VALUES ('107', '16', '14');
INSERT INTO `mini_goods_cate_relationships` VALUES ('108', '24', '14');
INSERT INTO `mini_goods_cate_relationships` VALUES ('109', '6', '18');
INSERT INTO `mini_goods_cate_relationships` VALUES ('118', '31', '3');
INSERT INTO `mini_goods_cate_relationships` VALUES ('119', '31', '20');
INSERT INTO `mini_goods_cate_relationships` VALUES ('125', '32', '18');
INSERT INTO `mini_goods_cate_relationships` VALUES ('127', '30', '20');
INSERT INTO `mini_goods_cate_relationships` VALUES ('128', '30', '5');
INSERT INTO `mini_goods_cate_relationships` VALUES ('129', '33', '3');
INSERT INTO `mini_goods_cate_relationships` VALUES ('130', '33', '20');
INSERT INTO `mini_goods_cate_relationships` VALUES ('133', '34', '3');
INSERT INTO `mini_goods_cate_relationships` VALUES ('134', '28', '9');
INSERT INTO `mini_goods_cate_relationships` VALUES ('135', '35', '20');
INSERT INTO `mini_goods_cate_relationships` VALUES ('138', '36', '19');
INSERT INTO `mini_goods_cate_relationships` VALUES ('139', '37', '20');
INSERT INTO `mini_goods_cate_relationships` VALUES ('140', '29', '8');
INSERT INTO `mini_goods_cate_relationships` VALUES ('141', '37', '19');
INSERT INTO `mini_goods_cate_relationships` VALUES ('142', '38', '1');
INSERT INTO `mini_goods_cate_relationships` VALUES ('143', '38', '19');
INSERT INTO `mini_goods_cate_relationships` VALUES ('144', '39', '19');
INSERT INTO `mini_goods_cate_relationships` VALUES ('145', '40', '1');
INSERT INTO `mini_goods_cate_relationships` VALUES ('146', '41', '1');
INSERT INTO `mini_goods_cate_relationships` VALUES ('147', '41', '19');
INSERT INTO `mini_goods_cate_relationships` VALUES ('150', '42', '9');
INSERT INTO `mini_goods_cate_relationships` VALUES ('152', '44', '22');
INSERT INTO `mini_goods_cate_relationships` VALUES ('208', '48', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('209', '48', '34');
INSERT INTO `mini_goods_cate_relationships` VALUES ('210', '48', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('211', '48', '36');
INSERT INTO `mini_goods_cate_relationships` VALUES ('212', '48', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('216', '45', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('217', '45', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('218', '45', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('223', '43', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('224', '43', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('225', '43', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('226', '47', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('227', '47', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('228', '46', '20');
INSERT INTO `mini_goods_cate_relationships` VALUES ('229', '46', '27');

-- -----------------------------
-- Table structure for `mini_goods_collection`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_collection`;
CREATE TABLE `mini_goods_collection` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL COMMENT '用户id',
  `goods_id` int(10) DEFAULT NULL COMMENT '商品id',
  `createtime` varchar(11) DEFAULT NULL COMMENT '收藏时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_goods_comment`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_comment`;
CREATE TABLE `mini_goods_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增唯一ID',
  `uid` int(20) DEFAULT NULL,
  `goods_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应文章ID',
  `order_id` varchar(20) DEFAULT NULL COMMENT '订单号',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '评论时间',
  `content` text NOT NULL COMMENT '评论正文',
  `approved` varchar(20) NOT NULL DEFAULT '0' COMMENT '审核 0-待审核  1-已审核',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父评论ID',
  `score` int(2) DEFAULT NULL COMMENT '商品评分',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 -1-删除  1-正常',
  PRIMARY KEY (`id`),
  KEY `comment_post_ID` (`goods_id`),
  KEY `comment_approved_date_gmt` (`approved`),
  KEY `comment_parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_key_value`
-- -----------------------------
DROP TABLE IF EXISTS `mini_key_value`;
CREATE TABLE `mini_key_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection` varchar(128) NOT NULL COMMENT '命名集合键和值对',
  `uuid` varchar(128) NOT NULL DEFAULT 'default' COMMENT '系统唯一标识',
  `name` varchar(128) NOT NULL COMMENT '键名',
  `value` longtext NOT NULL COMMENT 'The value.',
  PRIMARY KEY (`id`,`collection`,`uuid`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_key_value`
-- -----------------------------
INSERT INTO `mini_key_value` VALUES ('1', 'config.base', 'default', 'web_allow_register', '1');
INSERT INTO `mini_key_value` VALUES ('2', 'config.base', 'default', 'web_site_close', '0');
INSERT INTO `mini_key_value` VALUES ('3', 'config.base', 'default', 'web_site_description', '小微企业电子商城');
INSERT INTO `mini_key_value` VALUES ('4', 'config.base', 'default', 'web_site_icp', '冀ICP备XXXXXXX');
INSERT INTO `mini_key_value` VALUES ('5', 'config.base', 'default', 'web_site_keyword', '小微，云商，商城，官网');
INSERT INTO `mini_key_value` VALUES ('6', 'config.base', 'default', 'web_site_title', '小微云商');
INSERT INTO `mini_key_value` VALUES ('7', 'config.base', 'default', 'web_allow_ticket', '0');
INSERT INTO `mini_key_value` VALUES ('8', 'indextheme', 'default', 'name', 'qintu');
INSERT INTO `mini_key_value` VALUES ('8', 'users', 'ad75820a-96c3-a1a8-20c6-195534dd75d3', 'is_root', '1');
INSERT INTO `mini_key_value` VALUES ('9', 'posts.form', '9db99141-65a4-2393-bfa8-d4d100e1a1f4', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('10', 'posts.form', '1d3fa553-6e07-eed6-f459-4694de378122', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('11', 'term.taxonomy', '1caad667-985e-4b91-ef4a-fbbac872fbce', 'page_num', '20');
INSERT INTO `mini_key_value` VALUES ('12', 'term.taxonomy', '1caad667-985e-4b91-ef4a-fbbac872fbce', 'lists_tpl', 'news_list');
INSERT INTO `mini_key_value` VALUES ('13', 'term.taxonomy', '1caad667-985e-4b91-ef4a-fbbac872fbce', 'detail_tpl', 'news_detail');
INSERT INTO `mini_key_value` VALUES ('14', 'term.taxonomy', '1caad667-985e-4b91-ef4a-fbbac872fbce', 'bind_form', 'article');
INSERT INTO `mini_key_value` VALUES ('15', 'term.taxonomy', '75d26c72-c68f-6c2b-3f5d-da6b85915a1c', 'page_num', '20');
INSERT INTO `mini_key_value` VALUES ('16', 'term.taxonomy', '75d26c72-c68f-6c2b-3f5d-da6b85915a1c', 'lists_tpl', 'news_list');
INSERT INTO `mini_key_value` VALUES ('17', 'term.taxonomy', '75d26c72-c68f-6c2b-3f5d-da6b85915a1c', 'detail_tpl', 'news_detail');
INSERT INTO `mini_key_value` VALUES ('18', 'term.taxonomy', '75d26c72-c68f-6c2b-3f5d-da6b85915a1c', 'bind_form', 'article');
INSERT INTO `mini_key_value` VALUES ('19', 'term.taxonomy', '8e830d6a-2be3-ad99-08b5-de279d877937', 'page_num', '20');
INSERT INTO `mini_key_value` VALUES ('20', 'term.taxonomy', '8e830d6a-2be3-ad99-08b5-de279d877937', 'lists_tpl', 'news_list');
INSERT INTO `mini_key_value` VALUES ('21', 'term.taxonomy', '8e830d6a-2be3-ad99-08b5-de279d877937', 'detail_tpl', 'news_detail');
INSERT INTO `mini_key_value` VALUES ('22', 'term.taxonomy', '8e830d6a-2be3-ad99-08b5-de279d877937', 'bind_form', 'article');
INSERT INTO `mini_key_value` VALUES ('29', 'posts.form', '085b628d-d8ae-d04c-dfa0-61992ca70f29', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('30', 'posts.form', '3cf4069c-80d0-ac82-fcfe-e7e378569c12', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('31', 'posts.form', '7df6d672-48ef-b8ed-1d18-74c3770dcbc3', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('32', 'posts.form', '7faa2c91-b173-6bd2-4b69-c0234c7c1a57', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('33', 'posts.form', 'b64c7e04-b8a0-eeda-0314-35eabe258111', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('34', 'posts.form', '8bc618f8-c8a4-2219-fee2-2da0a71ca8ff', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('35', 'posts.form', '8cfc3471-3754-30cb-b030-a11dba360e0c', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('36', 'posts.form', '9bb4e644-482b-c2cd-68c7-9a1a2f290435', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('37', 'posts.form', '1c6e5535-86e8-6e0b-548b-02e631b85b20', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('38', 'posts.form', '879bda21-07f8-df3c-9270-7789515157ed', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('39', 'posts.form', '74610495-ab86-d787-fa50-8ba3987b680b', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('40', 'posts.form', '76ce6961-894e-8d13-59c4-49881ddf6748', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('41', 'posts.form', '94714551-683d-aa79-6fb4-60dd70201473', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('42', 'posts.form', '11646a6e-cd35-bcdd-4136-c5b392b63a6f', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('43', 'posts.form', 'd27eea5e-e553-d2d5-b05b-9574af56ce3f', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('44', 'posts.form', '60e38eeb-97a5-61ac-be60-425f9f8eb1c5', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('45', 'posts.form', 'f569d8f0-0510-8c55-2cbf-f29a4ffea591', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('46', 'posts.form', 'e4ec7532-1686-71f3-f57e-e19cc49a81bf', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('47', 'posts.form', 'fabe0485-4f82-643a-6a46-cd8defc7f6d4', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('48', 'posts.form', '88de9d39-21e8-d00f-c8ff-2b56791ea559', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('49', 'users', '9fe83c25-864e-7fe8-370d-d97799be1d7e', 'is_root', '1');
INSERT INTO `mini_key_value` VALUES ('50', 'posts.form', 'f4d643a2-8507-fd72-c5af-e12a7e77b13a', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('51', 'posts.form', '6571e5b9-cf41-5e25-0cb9-9e7d07e62173', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('52', 'posts.form', '442721ec-7a93-0baa-cd58-a469fae43c13', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('53', 'posts.form', '6f4c8587-03e6-9d31-4325-c97384457543', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('54', 'posts.form', '9d348e6e-db9d-0ec9-4a36-666787af9a74', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('55', 'posts.form', 'b30eeb11-1ca4-e771-562f-644b56c66a7e', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('56', 'posts.form', 'fdd989d9-d0f4-64f8-6981-5e3945d089c0', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('66', 'posts.form', 'd5f45d6b-f40c-b798-c9ef-7d690078a166', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('67', 'posts.form', '5df49b2a-c711-301d-8320-af500ceb40c6', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('68', 'posts.form', '896d0d4d-cc3b-f43b-2000-e9604769eea0', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('69', 'posts.form', 'd842871c-3840-f944-efb2-caefedcf926e', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('70', 'posts.form', '3d57ca49-c45e-2266-067c-67cb2bde8603', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('71', 'posts.form', 'a3fc44c5-5731-114c-d576-cebcb6767ff7', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('72', 'posts.form', '591f72fc-def5-dc1d-1471-8bcb50b7d60d', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('73', 'posts.form', '0e05d041-23de-e42b-c88f-d3eb6c4dc365', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('153', 'posts.form', '224ac0b6-a569-3d4d-aad4-f96d5cf4869d', 'description', '打造迁安农产品的名、特、优品牌');
INSERT INTO `mini_key_value` VALUES ('154', 'posts.cover', '224ac0b6-a569-3d4d-aad4-f96d5cf4869d', 'cover_path_1', '/uploads/picture/20161206/fe70c72e47a91eb25ac27d80760a71b6.png');
INSERT INTO `mini_key_value` VALUES ('155', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'page_num', '20');
INSERT INTO `mini_key_value` VALUES ('156', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'lists_tpl', 'news_list');
INSERT INTO `mini_key_value` VALUES ('157', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'detail_tpl', 'news_detail');
INSERT INTO `mini_key_value` VALUES ('158', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'bind_form', 'article');
INSERT INTO `mini_key_value` VALUES ('159', 'posts.form', '32812f56-1972-7d72-92f2-33e680939959', 'description', '');
INSERT INTO `mini_key_value` VALUES ('162', 'posts.form', '6b314ef5-23cc-77bb-275b-07a821988c5d', 'description', '已有567位朋友亲身体验了亲途的不一样。');
INSERT INTO `mini_key_value` VALUES ('163', 'posts.form', '16ce5fa3-328d-69a1-a173-76c7b7a8f790', 'description', '');
INSERT INTO `mini_key_value` VALUES ('164', 'posts.form', '21af88c5-496f-91ec-c5c6-2807ecfeacf2', 'description', '');
INSERT INTO `mini_key_value` VALUES ('165', 'posts.form', '56f9a7a3-57f5-7a07-fb6f-866ad7ef9e8b', 'description', '');
INSERT INTO `mini_key_value` VALUES ('166', 'posts.form', '70654547-9aec-c618-9753-e80dd876181a', 'page_tpl', 'page_srdz');
INSERT INTO `mini_key_value` VALUES ('167', 'posts.form', 'e522aff9-c7d0-9cd2-0f07-7e428c622e5b', 'page_tpl', 'page_srdz');
INSERT INTO `mini_key_value` VALUES ('168', 'posts.form', '94a5b422-2d0b-072a-bee5-2179a7793615', 'page_tpl', 'page_syjl');

-- -----------------------------
-- Table structure for `mini_links`
-- -----------------------------
DROP TABLE IF EXISTS `mini_links`;
CREATE TABLE `mini_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增唯一ID',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接URL',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '链接标题',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '链接图片',
  `target` varchar(25) NOT NULL DEFAULT '' COMMENT '链接打开方式',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '链接描述',
  `visible` varchar(20) NOT NULL DEFAULT 'Y' COMMENT '是否可见（Y/N）',
  `owner` bigint(20) unsigned NOT NULL DEFAULT '1' COMMENT '添加者用户ID',
  `createtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `link_visible` (`visible`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_links`
-- -----------------------------
INSERT INTO `mini_links` VALUES ('1', 'http://www.baidu.com', '百度', '/uploads/picture/20161209/707e87d63b2b3b561df33d8a510b19cf.png', '_blank', '百度', 'Y', '1', '1474877272');

-- -----------------------------
-- Table structure for `mini_menu`
-- -----------------------------
DROP TABLE IF EXISTS `mini_menu`;
CREATE TABLE `mini_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_menu`
-- -----------------------------
INSERT INTO `mini_menu` VALUES ('1', '文章', 'fa fa-fw fa-files-o', '0', '0', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('2', '订单', 'fa fa-fw fa-exchange', '0', '3', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('3', '会员', 'fa fa-fw fa-users', '0', '4', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('4', '设置', 'fa fa-gears', '0', '5', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('5', '个人', 'fa fa-fw fa-user', '0', '6', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('31', '写文章', 'fa fa-fw fa-edit', '1', '1', 'post/add', '0', '0');
INSERT INTO `mini_menu` VALUES ('32', '所有文章', 'fa fa-fw fa-file', '1', '0', 'post/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('37', '分类目录', 'fa fa-fw fa-cubes', '1', '2', 'taxonomy/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('38', '订单列表', 'fa fa-money', '2', '0', 'order/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('39', '会员列表', 'fa fa-fw fa-user', '3', '0', 'member/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('40', '添加会员', 'fa fa-fw fa-user-plus', '3', '1', 'member/add', '0', '0');
INSERT INTO `mini_menu` VALUES ('41', '基本设置', 'fa  fa-wrench', '4', '0', 'config/edit', '0', '0');
INSERT INTO `mini_menu` VALUES ('42', '菜单设置', 'fa  fa-navicon ', '4', '1', 'menu/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('43', '个人资料', 'fa fa-user-times', '5', '0', 'user/edit', '0', '0');
INSERT INTO `mini_menu` VALUES ('44', '修改密码', 'fa fa-fw fa-key', '5', '1', 'user/password', '0', '0');
INSERT INTO `mini_menu` VALUES ('48', '插件', 'fa fa-puzzle-piece', '0', '7', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('49', '广告管理', 'fa  fa-picture-o', '48', '1', 'banner/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('50', '导航设置', 'fa  fa-cog', '4', '2', 'navigation/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('51', '页面', 'fa fa-newspaper-o', '0', '1', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('52', '所有页面', 'fa fa-fw fa-file', '51', '0', 'page/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('53', '新增页面', 'fa fa-edit (alias)', '51', '1', 'page/add', '0', '0');
INSERT INTO `mini_menu` VALUES ('54', '权限设置', 'fa fa-plug', '4', '0', 'authmanager/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('55', '广告位置', 'fa fa-picture-o', '48', '0', 'banner_position/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('56', '链接管理', 'fa fa-link', '48', '3', 'links/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('59', '登录', '', '0', '0', 'index/index', '1', '0');
INSERT INTO `mini_menu` VALUES ('58', '评论管理', 'fa fa-comment-o', '48', '0', 'comment/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('60', '删除分类', '', '37', '0', 'taxonomyt/setStatus', '1', '0');
INSERT INTO `mini_menu` VALUES ('61', '添加分类目录', '', '37', '0', 'taxonomy/edit', '1', '0');
INSERT INTO `mini_menu` VALUES ('64', '主题设置', 'fa fa-sliders', '4', '5', 'theme/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('65', '微信设置', 'fa fa-plug', '4', '0', 'wx/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('67', '接口设置', 'fa fa-support', '4', '7', 'apiconfig/edit', '0', '0');
INSERT INTO `mini_menu` VALUES ('68', '数据库', 'fa fa-cog', '0', '8', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('69', '数据库备份', 'fa fa-cog', '68', '0', 'Database/index?type=export', '0', '0');
INSERT INTO `mini_menu` VALUES ('70', '数据库还原', 'fa fa-cog', '68', '0', 'Database/index?type=import', '0', '0');
INSERT INTO `mini_menu` VALUES ('71', '商品', 'fa fa-shopping-cart', '0', '2', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('72', '所有商品', ' fa fa-shopping-cart', '71', '0', 'goods/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('73', '添加商品', 'fa  fa-plus-square', '71', '1', 'goods/goodsAdd', '0', '0');
INSERT INTO `mini_menu` VALUES ('74', '商品分类', 'fa fa-list', '71', '2', 'goods/category', '0', '0');
INSERT INTO `mini_menu` VALUES ('75', '私人需求单', 'fa fa-money', '2', '0', 'order/person', '0', '0');
INSERT INTO `mini_menu` VALUES ('76', '商业需求单', 'fa fa-money', '2', '0', 'order/business', '0', '0');

-- -----------------------------
-- Table structure for `mini_navigation`
-- -----------------------------
DROP TABLE IF EXISTS `mini_navigation`;
CREATE TABLE `mini_navigation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_navigation`
-- -----------------------------
INSERT INTO `mini_navigation` VALUES ('1', '轻定制', 'fa fa-fw fa-files-o', '0', '0', 'goods/lists?category=qdz_area_all|qdz_tese_all', '0');
INSERT INTO `mini_navigation` VALUES ('2', '亲途达人', 'fa fa-fw fa-exchange', '0', '1', 'goods/lists?category=qtdr_area_all|qtdr_tese_all', '0');
INSERT INTO `mini_navigation` VALUES ('3', '私人定制', 'fa fa-fw fa-users', '0', '2', 'article/page?name=srdz', '0');
INSERT INTO `mini_navigation` VALUES ('4', '主题路线', 'fa fa-gears', '0', '3', 'goods/lists?category=ztdz', '0');
INSERT INTO `mini_navigation` VALUES ('5', '商业交流', 'fa fa-fw fa-edit', '0', '5', 'article/page?name=syjl', '0');

-- -----------------------------
-- Table structure for `mini_orders`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders`;
CREATE TABLE `mini_orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `order_no` varchar(20) NOT NULL COMMENT '订单号',
  `print_no` varchar(30) DEFAULT NULL COMMENT '小票打印机单号',
  `express_type` varchar(100) DEFAULT NULL COMMENT '快递方式',
  `express_no` varchar(100) DEFAULT NULL COMMENT '快递编号',
  `pay_type` varchar(10) NOT NULL COMMENT '支付方式',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `createtime` int(11) NOT NULL,
  `is_pay` int(11) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL COMMENT '支付状态',
  `memo` varchar(255) DEFAULT NULL COMMENT '订单备注',
  `consignee_name` varchar(100) DEFAULT NULL COMMENT '收货人',
  `address` text COMMENT '收货地址',
  `mobile` varchar(11) DEFAULT NULL COMMENT '收货人电话',
  PRIMARY KEY (`id`,`uuid`,`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders`
-- -----------------------------
INSERT INTO `mini_orders` VALUES ('73', '442ba8af-7fd7-84f6-1a30-6140f85703bd', '1', '2017032353485397', '', '', '', 'wxpay', '700.00', '1490255221', '0', 'nopaid', '', '哈哈', '北京东城区了开发的发放', '13810773215');
INSERT INTO `mini_orders` VALUES ('74', 'ae637617-0e7f-6986-f645-68edfe99cd9f', '1', '2017032456564853', '', '', '', 'wxpay', '760.00', '1490332760', '0', 'nopaid', '', '哈哈', '北京东城区了开发的发放', '13810773215');
INSERT INTO `mini_orders` VALUES ('79', 'aaa6704e-636e-0dba-f3f1-06c58d9da20e', '1', '2017032498519799', '', '', '', '', '0.00', '1490341083', '1', '', '', '', '', '');
INSERT INTO `mini_orders` VALUES ('80', 'ca6419eb-1dbd-81f5-bb75-4dcd78b53f82', '1', '2017032410155525', '', '', '', '', '0.00', '1490341454', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('81', '1f93c9b2-1d89-efc9-6894-0f15cca621bd', '1', '2017032457515455', '', '', '', '', '0.00', '1490341545', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('82', '065d1da4-f4c8-0d5f-03fc-2f7694689cea', '1', '2017032448971001', '', '', '', '', '0.00', '1490342192', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('83', 'abb562af-0a28-3d8b-839e-a216377eeb85', '1', '2017032410152519', '', '', '', '', '0.00', '1490343230', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('84', 'd866706e-e4d7-3ef2-c865-b26955eff6f9', '1', '2017032451529949', '', '', '', '', '0.00', '1490343235', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('85', '927cd2de-0f6a-c79f-c4d7-0479c614737f', '1', '2017032455545048', '', '', '', '', '0.00', '1490343911', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('86', '0ed8024c-debd-8779-8f92-6bac59994a8c', '1', '2017032498971025', '', '', '', '', '0.00', '1490343915', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('87', 'b69613f5-e48c-fac5-6a15-9d20ee765bff', '1', '2017032410250100', '', '', '', '', '0.00', '1490344127', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('88', 'a9ec269c-631f-403b-0b6e-6b6e368e94d8', '1', '2017032749495698', '', '', '', '', '0.00', '1490590129', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('89', 'd08e7097-f06c-c3a7-4092-e9841f0d17e0', '1', '2017032757995251', '', '', '', '', '0.00', '1490590137', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('90', '05f4ce26-483d-f1b2-504c-456c63a1646c', '1', '2017032710199555', '', '', '', '', '0.00', '1490590174', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('91', '35dc6982-5bdb-0f17-c1e8-23a96a7521a7', '1', '2017032755545051', '', '', '', '', '0.00', '1490590183', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('92', '6640c8d9-5740-a8d0-5d20-8411518eaed5', '1', '2017032748995710', '', '', '', '', '0.00', '1490590208', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('93', 'ae79a01e-db4d-0cd0-5b31-0c01dc6dae20', '1', '2017032752565148', '', '', '', '', '0.00', '1490590244', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('94', '4716317c-16c1-8a81-c898-ff09321941c6', '1', '2017032749539755', '', '', '', '', '0.00', '1490590257', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('95', '13628904-129d-2554-eeb3-cff4a5ea9571', '1', '2017032798511001', '', '', '', '', '0.00', '1490590411', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('96', '4b10ac91-24c4-934b-92ed-9f6b211f7a49', '1', '2017032751515656', '', '', '', '', '0.00', '1490590467', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('97', '47b3a405-df5a-9edd-48c0-f6bf72e932ee', '1', '2017032856971025', '', '', '', '', '0.00', '1490686360', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('98', '121bc992-3daa-9523-1015-37fba6782091', '1', '2017032810256541', '', '', '', '', '0.00', '1490686479', '0', '', '', '', '', ' ');

-- -----------------------------
-- Table structure for `mini_orders_address`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_address`;
CREATE TABLE `mini_orders_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `consignee_name` varchar(100) NOT NULL COMMENT '收货人',
  `province` varchar(100) NOT NULL COMMENT '省',
  `city` varchar(100) NOT NULL COMMENT '市',
  `county` varchar(100) NOT NULL COMMENT '县/区',
  `address` text NOT NULL COMMENT '详细地址',
  `mobile` varchar(11) NOT NULL COMMENT '联系电话',
  `status` int(10) NOT NULL DEFAULT '1' COMMENT '1-正常 -1-已删除',
  `default` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为默认收货地址1-是 0-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders_address`
-- -----------------------------
INSERT INTO `mini_orders_address` VALUES ('14', '1', '哈哈', '北京', '东城区', '', '了开发的发放', '13810773215', '1', '1');

-- -----------------------------
-- Table structure for `mini_orders_goods`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_goods`;
CREATE TABLE `mini_orders_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(11) NOT NULL COMMENT '订单号',
  `goods_id` int(11) NOT NULL COMMENT '商品id',
  `name` varchar(255) NOT NULL,
  `num` int(10) NOT NULL COMMENT '购买数量',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `description` text NOT NULL,
  `standard` varchar(255) NOT NULL,
  `cover_path` varchar(255) NOT NULL,
  `is_comment` varchar(10) NOT NULL DEFAULT '-1' COMMENT '商品是否评论 -1-否  1-是',
  `departure_time` int(11) NOT NULL,
  `man_num` int(10) NOT NULL,
  `child_num` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders_goods`
-- -----------------------------
INSERT INTO `mini_orders_goods` VALUES ('74', '73', '42', '红枣夹核桃', '28', '25.00', '红枣夹核桃', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '-1', '0', '0', '0');
INSERT INTO `mini_orders_goods` VALUES ('75', '74', '44', '核桃仁', '1', '35.00', '核桃仁', '100克X10袋', '/uploads/picture/20161223/9da72a3997817954407982362b3ac40a.jpg', '-1', '0', '0', '0');
INSERT INTO `mini_orders_goods` VALUES ('76', '74', '42', '红枣夹核桃', '29', '25.00', '红枣夹核桃', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '-1', '0', '0', '0');
INSERT INTO `mini_orders_goods` VALUES ('79', '79', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('80', '80', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('81', '81', '0', '', '0', '0.00', '', '', '', '-1', '2017', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('82', '82', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('83', '83', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('84', '84', '0', '', '0', '0.00', '', '', '', '-1', '2147483647', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('85', '85', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('86', '86', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1488412800', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('87', '87', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1488585600', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('88', '88', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('89', '89', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('90', '90', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('91', '91', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('92', '92', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('93', '93', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('94', '94', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('95', '95', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1488931200', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('96', '96', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1490227200', '1', '0');

-- -----------------------------
-- Table structure for `mini_orders_status`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_status`;
CREATE TABLE `mini_orders_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) NOT NULL COMMENT '订单号',
  `approve_uid` int(50) DEFAULT NULL COMMENT '审核人',
  `trade_no` varchar(50) DEFAULT NULL COMMENT '支付接口流水号',
  `trade_status` varchar(50) DEFAULT NULL COMMENT '支付接口状态',
  `status` varchar(30) NOT NULL COMMENT 'nopaid-未支付 paid-已支付,待发货  shipped-已发货  completed-收货已完成',
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_person_need`
-- -----------------------------
DROP TABLE IF EXISTS `mini_person_need`;
CREATE TABLE `mini_person_need` (
  `name` char(128) NOT NULL COMMENT '姓名',
  `mobile` varchar(128) NOT NULL COMMENT '手机号',
  `email` char(128) NOT NULL COMMENT '邮箱',
  `reached` char(128) DEFAULT NULL COMMENT '目的地',
  `out_date` char(128) DEFAULT NULL COMMENT '出行日期',
  `out_days` char(128) DEFAULT NULL COMMENT '出行天数',
  `man` int(11) DEFAULT NULL COMMENT '成人人数',
  `children` int(11) DEFAULT NULL COMMENT '儿童人数',
  `cost` char(128) DEFAULT NULL COMMENT '预计花费',
  `description` text COMMENT '备注',
  `createtime` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_person_need`
-- -----------------------------
INSERT INTO `mini_person_need` VALUES ('111111111111', '2147483647', '11@qq.com', '', '', '', '0', '0', '￥10000-￥30000', '', '0');
INSERT INTO `mini_person_need` VALUES ('11111111', '17744484319', '11@qq.com', '', '', '', '0', '0', '', '', '1490695473');

-- -----------------------------
-- Table structure for `mini_posts`
-- -----------------------------
DROP TABLE IF EXISTS `mini_posts`;
CREATE TABLE `mini_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增唯一ID',
  `uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应作者ID',
  `uuid` varchar(128) NOT NULL,
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `content` longtext NOT NULL COMMENT '正文',
  `title` text NOT NULL COMMENT '标题',
  `description` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish' COMMENT '文章状态（publish/draft/inherit等）',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open' COMMENT '评论状态（open/closed）',
  `password` varchar(20) NOT NULL DEFAULT '' COMMENT '文章密码',
  `name` varchar(200) NOT NULL DEFAULT '' COMMENT '文章缩略名',
  `updatetime` int(11) NOT NULL DEFAULT '0' COMMENT '修改时间',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父文章，主要用于PAGE',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `type` varchar(20) NOT NULL DEFAULT 'post' COMMENT '文章类型（post/page等）',
  `comment` bigint(20) NOT NULL DEFAULT '0' COMMENT '评论总数',
  `view` int(11) NOT NULL DEFAULT '0' COMMENT '文章浏览量',
  PRIMARY KEY (`id`),
  KEY `post_name` (`name`(191)),
  KEY `type_status_date` (`type`,`status`,`createtime`,`id`),
  KEY `post_parent` (`pid`),
  KEY `post_author` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_posts`
-- -----------------------------
INSERT INTO `mini_posts` VALUES ('1', '1', '86a350ae-3b57-9084-aca5-85b40bcbfc2b', '1474852188', '<p>关于我们<br/></p>', '关于我们', '', 'publish', 'open', '', '', '1474852188', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('2', '1', '3d57ca49-c45e-2266-067c-67cb2bde8603', '1474852669', '<p style="text-align: center;"><span style="font: 16px/28.8px &quot;Century Gothic&quot;, &quot;Microsoft yahei&quot;; color: rgb(50, 50, 50); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; white-space: normal; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;">&nbsp;<img title="1478831526237112.jpg" alt="IMG_20160107_103514.jpg" src="/uploads/editor/image/20161111/1478831526237112.jpg"/></span></p><p><span style="font-family: 宋体,SimSun; font-size: 20px;">&nbsp;&nbsp;&nbsp; 珍良缘农副食品超商，是迁安市供销合作社控股，联合迁安市春良蔬菜种植专业合作社，迁安市正农鹅养殖专业合作社，迁安市家乡土蔬菜种植专业合作社，迁安市华侨林果种植专业合作社，迁安市全文蔬菜种植专业合作社5家农民专业合作社共同搭建的农副产品展销平台，并作为迁安市供销合作社综合改革试点单位。<br/>&nbsp;&nbsp;&nbsp; 通过这个平台，把各专业合作社独具特色的产品展示出来，销售出去，实现强强联合，优势互补。珍良缘超商将展示销售绿色蔬菜、干鲜果品、禽蛋肉制品、深加工食品、特色粮油、调料副食、食用菌类以及国内外名优小食品等八大类千余种农副食品。<br/>&nbsp;&nbsp;&nbsp; 珍良缘超商以上庄乡供销农民专业合作社联合社为依托，拥有“春良”设施果菜现代农业园区、生态猪、羊养殖园区、“正农鹅”养殖园区、“长胜山”林果优质果品种植园区等高标准现代农业生产基地20000余亩，实现了农产品从田间地头，到商场超市的直营，即让合作社成员获得了较高的经济收益，也让广大消费者享受了便宜，优质，安全的农副产品，同时通过这个平台，不断加大迁安农产品的推介力度，打造迁安农产品的名、特、优品牌。<br/></span></p><p><span style="font: 16px/28.8px &quot;Century Gothic&quot;, &quot;Microsoft yahei&quot;; color: rgb(50, 50, 50); text-transform: none; text-indent: 0px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; white-space: normal; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;"></span></p>', '企业简介', '', 'publish', 'open', '', 'company', '1480560241', '1', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('3', '1', '591f72fc-def5-dc1d-1471-8bcb50b7d60d', '1474853044', '<p><span style="font: 20px/40px 宋体, SimSun; color: rgb(128, 128, 128); text-transform: none; text-indent: 20px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; white-space: normal; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;">&nbsp;&nbsp;&nbsp;&nbsp; 珍良缘超商以上庄乡供销农民专业合作社联合社为依托，拥有“春良”设施果菜现代农业园区、生态猪、羊养殖园区、“正农鹅”养殖园区、“长胜山”林果优质果品种植园区等高标准现代农业生产基地20000余亩，实现了农产品从田间地头，到商场超市的直营，即让合作社成员获得了较高的经济收益，也让广大消费者享受了便宜，优质，安全的农副产品，同时通过这个平台，不断加大迁安农产品的推介力度，打造迁安农产品的名、特、优品牌。</span></p>', '企业文化', '', 'publish', 'open', '', 'culture', '1480642489', '1', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('4', '1', '224ac0b6-a569-3d4d-aad4-f96d5cf4869d', '1474855015', '<p><span style="font: 14px/28px &quot;Microsoft YaHei&quot;, Verdana, Geneva, sans-serif; color: rgb(128, 128, 128); text-transform: none; text-indent: 20px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;"><span style="font: 20px/40px 宋体, SimSun; color: rgb(128, 128, 128); text-transform: none; text-indent: 20px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;">珍良缘农副食品超商，是迁安市供销合作社控股，联合迁安市春良蔬菜种植专业合作社，迁安市正农鹅养殖专业合作社，迁安市家乡土蔬菜种植专业合作社，迁安市华侨林果种植专业合作社，迁安市全文蔬菜种植专业合作社5家农民专业合作社共同搭建的农副产品展销平台，并作为迁安市供销合作社综合改革试点单位。</span><br/><span style="font: 20px/40px 宋体, SimSun; color: rgb(128, 128, 128); text-transform: none; text-indent: 20px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;">&nbsp;&nbsp;&nbsp; 通过这个平台，把各专业合作社独具特色的产品展示出来，销售出去，实现强强联合，优势互补。珍良缘超商将展示销售绿色蔬菜、干鲜果品、禽蛋肉制品、深加工食品、特色粮油、调料副食、食用菌类以及国内外名优小食品等八大类千余种农副食品。</span><br/><span style="font: 20px/40px 宋体, SimSun; color: rgb(128, 128, 128); text-transform: none; text-indent: 20px; letter-spacing: normal; word-spacing: 0px; float: none; display: inline !important; widows: 1; font-size-adjust: none; font-stretch: normal; background-color: rgb(255, 255, 255); -webkit-text-stroke-width: 0px;">&nbsp;&nbsp;&nbsp; 珍良缘超商以上庄乡供销农民专业合作社联合社为依托，拥有“春良”设施果菜现代农业园区、生态猪、羊养殖园区、“正农鹅”养殖园区、“长胜山”林果优质果品种植园区等高标准现代农业生产基地20000余亩，实现了农产品从田间地头，到商场超市的直营，即让合作社成员获得了较高的经济收益，也让广大消费者享受了便宜，优质，安全的农副产品，同时通过这个平台，不断加大迁安农产品的推介力度，打造迁安农产品的名、特、优品牌。</span></span></p>', '珍良缘农副食品超商', '', 'publish', 'open', '', 'test', '1489979625', '0', '0', 'post', '0', '52');
INSERT INTO `mini_posts` VALUES ('6', '1', '085b628d-d8ae-d04c-dfa0-61992ca70f29', '1474857641', '<p>发展历程</p>', '发展历程', '', 'publish', 'open', '', 'history', '1474857641', '1', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('7', '1', '0e05d041-23de-e42b-c88f-d3eb6c4dc365', '1474857699', '<p>内容更新中！<br/></p>', '资质荣誉', '', 'publish', 'open', '', 'honor', '1480649078', '1', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('8', '1', 'fdd989d9-d0f4-64f8-6981-5e3945d089c0', '1474861254', '<p>联系电话：0315-5967799</p><p>联系地址：迁安市惠宁大街南侧</p>', '公司地址', '', 'publish', 'open', '', 'address', '1480557559', '23', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('9', '1', 'b64c7e04-b8a0-eeda-0314-35eabe258111', '1474875879', '<p>帮助中心<br/></p>', '帮助中心', '', 'publish', 'open', '', 'help', '1474875879', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('10', '1', '9bb4e644-482b-c2cd-68c7-9a1a2f290435', '1474875914', '<p>购物指南</p>', '购物指南', '', 'publish', 'open', '', 'shopping', '1474875983', '9', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('11', '1', 'd5f45d6b-f40c-b798-c9ef-7d690078a166', '1474875963', '<p><img title="1480559654886652.png" alt="S~`UBNZ9H05Z_3~E17GNXIG.png" src="/uploads/editor/image/20161201/1480559654886652.png"/></p>', '账号注册', '', 'publish', 'open', '', 'registration', '1480559658', '10', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('12', '1', '5df49b2a-c711-301d-8320-af500ceb40c6', '1474876064', '<p>购物流程：注册会员成功后，可点击商品“立即购买”进行付款。</p><p><img title="1480559911882615.png" alt="HP86S307RN)2K{D@WVPF]DL.png" src="/uploads/editor/image/20161201/1480559911882615.png"/></p>', '购物流程', '', 'publish', 'open', '', 'process', '1480559915', '10', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('13', '1', '879bda21-07f8-df3c-9270-7789515157ed', '1474876127', '<p>售后服务<br/></p>', '售后服务', '', 'publish', 'open', '', 'service', '1474876127', '9', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('14', '1', '74610495-ab86-d787-fa50-8ba3987b680b', '1474876180', '<p>先行赔付</p>', '先行赔付', '', 'publish', 'open', '', 'payment', '1474876180', '13', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('15', '1', '896d0d4d-cc3b-f43b-2000-e9604769eea0', '1474876216', '<p>退货电话：0315-5967799</p><p>退货地址：迁安市惠宁大街南侧</p>', '退货流程', '', 'publish', 'open', '', 'refund', '1480559982', '13', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('16', '1', '94714551-683d-aa79-6fb4-60dd70201473', '1474876249', '<p>投诉举报</p>', '投诉举报', '', 'publish', 'open', '', 'complain', '1474876249', '13', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('17', '1', '11646a6e-cd35-bcdd-4136-c5b392b63a6f', '1474876284', '<p>支付方式</p>', '支付方式', '', 'publish', 'open', '', 'payway', '1474876284', '9', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('18', '1', 'd27eea5e-e553-d2d5-b05b-9574af56ce3f', '1474876316', '<p>支付宝</p>', '支付宝', '', 'publish', 'open', '', 'alipay', '1474876316', '17', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('19', '1', 'f569d8f0-0510-8c55-2cbf-f29a4ffea591', '1474876350', '<p>微信支付</p>', '微信支付', '', 'publish', 'open', '', 'wxpay', '1474876382', '17', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('20', '1', 'e4ec7532-1686-71f3-f57e-e19cc49a81bf', '1474876431', '<p>配送方式<br/></p>', '配送方式', '', 'publish', 'open', '', 'distributionway', '1474876431', '9', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('21', '1', 'd842871c-3840-f944-efb2-caefedcf926e', '1474876534', '<p>配送范围：迁安市区内</p>', '配送范围', '', 'publish', 'open', '', 'distribution', '1480560010', '20', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('22', '1', 'a3fc44c5-5731-114c-d576-cebcb6767ff7', '1474876595', '<p>迁安市区范围内免费送货</p>', '运费计算', '', 'publish', 'open', '', 'freight', '1480577041', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('23', '1', 'b94c42ac-4612-93aa-fe5a-267b35f86824', '1478587859', '<p>联系我们<br/></p>', '联系我们', '', 'publish', 'open', '', '', '1478587859', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('56', '1', '32812f56-1972-7d72-92f2-33e680939959', '1489980237', '<ol class=" list-paddingleft-2" style="list-style-type: decimal;"><li><p>为什么选择亲途？</p></li><li><p>为什么选择亲途？</p></li><li><p>为什么选择亲途？</p></li><li><p>为什么选择亲途？</p></li><li><p>为什么选择亲途？</p></li><li><p>为什么选择亲途？<br/></p></li></ol>', '为什么选择亲途？', '', 'publish', 'open', '', 'why-choose', '1489980237', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('57', '1', '6b314ef5-23cc-77bb-275b-07a821988c5d', '1489982273', '<table style="text-align: center;"><tbody><tr class="firstRow"><td width="33.333%" valign="top" style="word-break: break-all;">q</td><td width="33.333%" valign="top" style="word-break: break-all;">q</td><td width="33.333%" valign="top" style="word-break: break-all;">q</td></tr><tr><td width="33.333%" valign="top" style="word-break: break-all;">q</td><td width="33.333%" valign="top"><br/></td><td width="33.333%" valign="top" style="word-break: break-all;">q</td></tr></tbody></table><p style="text-align: center;"><br/></p>', '轻定制服务流程', '', 'publish', 'open', '', 'qdz-server-process', '1489982745', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('58', '1', '16ce5fa3-328d-69a1-a173-76c7b7a8f790', '1489990844', '<p><span style="font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;">什么是轻定制？</span></p><p><font face="微软雅黑, Microsoft YaHei">放大机卡分离的积分</font></p>', '常见问题', '', 'publish', 'open', '', 'question-qdz', '1489990844', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('59', '1', '21af88c5-496f-91ec-c5c6-2807ecfeacf2', '1489990947', '<p>发动机卡积分卡；积分卡</p>', '费用说明', '', 'publish', 'open', '', 'cost-qdz', '1489990947', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('60', '1', '56f9a7a3-57f5-7a07-fb6f-866ad7ef9e8b', '1490601140', '<p>1111<br/></p>', '达人体验服务流程', '', 'publish', 'open', '', 'qtdr-server-process', '1490601140', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('61', '1', 'e522aff9-c7d0-9cd2-0f07-7e428c622e5b', '1490686244', '<p>11111</p>', '私人定制', '', 'publish', 'open', '', 'srdz', '1490686344', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('62', '1', '94a5b422-2d0b-072a-bee5-2179a7793615', '1490691894', '<p>saaaa</p>', '商业交流', '', 'publish', 'open', '', 'syjl', '1490691894', '0', '0', 'page', '0', '0');

-- -----------------------------
-- Table structure for `mini_term_relationships`
-- -----------------------------
DROP TABLE IF EXISTS `mini_term_relationships`;
CREATE TABLE `mini_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应文章ID/链接ID',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应分类方法ID',
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_term_relationships`
-- -----------------------------
INSERT INTO `mini_term_relationships` VALUES ('4', '2', '0');
INSERT INTO `mini_term_relationships` VALUES ('4', '1', '0');
INSERT INTO `mini_term_relationships` VALUES ('56', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('57', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('58', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('59', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('60', '12', '0');

-- -----------------------------
-- Table structure for `mini_term_taxonomy`
-- -----------------------------
DROP TABLE IF EXISTS `mini_term_taxonomy`;
CREATE TABLE `mini_term_taxonomy` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类方法ID',
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类方法(post_tag)',
  `uuid` varchar(128) NOT NULL,
  `taxonomy` varchar(32) NOT NULL DEFAULT '' COMMENT '分类方法(category)',
  `description` longtext NOT NULL,
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '所属父分类方法ID',
  `count` bigint(20) NOT NULL DEFAULT '0' COMMENT '文章数统计',
  PRIMARY KEY (`id`,`count`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_term_taxonomy`
-- -----------------------------
INSERT INTO `mini_term_taxonomy` VALUES ('1', '1', '1caad667-985e-4b91-ef4a-fbbac872fbce', 'category', '', '0', '0');
INSERT INTO `mini_term_taxonomy` VALUES ('2', '2', '75d26c72-c68f-6c2b-3f5d-da6b85915a1c', 'category', '', '1', '1');
INSERT INTO `mini_term_taxonomy` VALUES ('3', '3', '8e830d6a-2be3-ad99-08b5-de279d877937', 'category', '', '1', '0');
INSERT INTO `mini_term_taxonomy` VALUES ('12', '12', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'category', '', '0', '5');

-- -----------------------------
-- Table structure for `mini_terms`
-- -----------------------------
DROP TABLE IF EXISTS `mini_terms`;
CREATE TABLE `mini_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(200) NOT NULL DEFAULT '' COMMENT '分类名',
  `slug` varchar(200) NOT NULL DEFAULT '' COMMENT '缩略名',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  `sort` decimal(50,0) NOT NULL COMMENT '用于排序',
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_terms`
-- -----------------------------
INSERT INTO `mini_terms` VALUES ('1', '新闻资讯', 'news', '0', '1');
INSERT INTO `mini_terms` VALUES ('2', '企业新闻', 'company-news', '0', '1');
INSERT INTO `mini_terms` VALUES ('3', '行业资讯', 'company-info', '0', '2');
INSERT INTO `mini_terms` VALUES ('12', '页面内容', 'page-block', '0', '0');

-- -----------------------------
-- Table structure for `mini_user_extend`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_extend`;
CREATE TABLE `mini_user_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` varchar(300) NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';


-- -----------------------------
-- Table structure for `mini_user_group`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_group`;
CREATE TABLE `mini_user_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为-1禁用',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_user_group`
-- -----------------------------
INSERT INTO `mini_user_group` VALUES ('1', 'admin', '1', '测试用户组', '', '1', '');

-- -----------------------------
-- Table structure for `mini_user_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_group_access`;
CREATE TABLE `mini_user_group_access` (
  `uid` bigint(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_user_rule`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_rule`;
CREATE TABLE `mini_user_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_users`
-- -----------------------------
DROP TABLE IF EXISTS `mini_users`;
CREATE TABLE `mini_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) NOT NULL COMMENT '系统唯一标识符',
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(64) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(11) NOT NULL,
  `regdate` int(10) NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL DEFAULT '0',
  `salt` varchar(6) NOT NULL DEFAULT '0' COMMENT '加密盐',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1正常，2禁用，-1删除',
  `last_login` int(11) DEFAULT NULL COMMENT '最后登录时间',
  `wechat_openid` varchar(255) DEFAULT NULL COMMENT '微信openid',
  `qq_openid` varchar(255) DEFAULT NULL COMMENT 'qqopenid',
  `sina_openid` varchar(255) NOT NULL COMMENT '微博openid',
  `score` int(11) DEFAULT '0' COMMENT '积分',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE,
  UNIQUE KEY `email` (`email`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_users`
-- -----------------------------
INSERT INTO `mini_users` VALUES ('1', 'ad75820a-96c3-a1a8-20c6-195534dd75d3', 'admin', 'e3725a90e473b27068b29205a7f7c2dd', 'admin', 'admin@qq.com', ' ', '1487298736', '1', '071cf9', '1', '1490340592', '', '', '', '0');
INSERT INTO `mini_users` VALUES ('30', '0018d7c7-15f1-58e5-5853-570e1bdfda17', '13810773215', 'bbde9d236d823fee26a48a4d525987ee', '111', '', '13810773215', '1490170291', '0', '3d10f9', '1', '1490331170', '', '', '', '0');

-- -----------------------------
-- Table structure for `mini_wx_menu`
-- -----------------------------
DROP TABLE IF EXISTS `mini_wx_menu`;
CREATE TABLE `mini_wx_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '菜单名',
  `type` mediumint(2) NOT NULL COMMENT '菜单类型(1跳转，2消息)',
  `url` varchar(225) NOT NULL COMMENT '菜单跳转地址',
  `msg` varchar(1000) NOT NULL COMMENT '回复消息',
  `parent` int(11) NOT NULL DEFAULT '0' COMMENT '父id',
  `key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_wx_reply`
-- -----------------------------
DROP TABLE IF EXISTS `mini_wx_reply`;
CREATE TABLE `mini_wx_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` mediumint(2) NOT NULL COMMENT '回复类型，1关注回复2消息回复3关键词回复',
  `key` varchar(225) DEFAULT NULL COMMENT '关键词',
  `msg` varchar(1000) DEFAULT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

