-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2017-03-31 10:31:27
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `mini_apiconfig`
-- -----------------------------
DROP TABLE IF EXISTS `mini_apiconfig`;
CREATE TABLE `mini_apiconfig` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `key` varchar(255) NOT NULL COMMENT '配置项名称',
  `value` varchar(255) NOT NULL COMMENT '配置项值',
  `description` varchar(255) DEFAULT NULL COMMENT '配置描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_apiconfig`
-- -----------------------------
INSERT INTO `mini_apiconfig` VALUES ('1', 'print_apikey', '', 'API密钥');
INSERT INTO `mini_apiconfig` VALUES ('2', 'print_machine_code', '', '打印机终端号');
INSERT INTO `mini_apiconfig` VALUES ('3', 'print_msign', '', '打印机密钥');
INSERT INTO `mini_apiconfig` VALUES ('4', 'print_mobiliphone', '', '终端内部手机号');
INSERT INTO `mini_apiconfig` VALUES ('5', 'print_partner', '', '易连云用户ID');
INSERT INTO `mini_apiconfig` VALUES ('6', 'print_username', '', '易连云用户名');
INSERT INTO `mini_apiconfig` VALUES ('7', 'print_printname', '', '打印机终端名称');
INSERT INTO `mini_apiconfig` VALUES ('8', 'sms_appkey', '', 'Key值');
INSERT INTO `mini_apiconfig` VALUES ('9', 'sms_appsecret', '', '密钥');
INSERT INTO `mini_apiconfig` VALUES ('10', 'sms_template_code', '', '模板ID');
INSERT INTO `mini_apiconfig` VALUES ('11', 'sms_signname', '', '签名名称');
INSERT INTO `mini_apiconfig` VALUES ('12', 'alipay_partner', '', '合作身份者ID，签约账号，以2088开头由16位纯数字组成的字符串');
INSERT INTO `mini_apiconfig` VALUES ('13', 'alipay_appkey', '', ' MD5密钥，安全检验码，由数字和字母组成的32位字符串');
INSERT INTO `mini_apiconfig` VALUES ('14', 'wechat_appid', '', '微信公众号身份的唯一标识');
INSERT INTO `mini_apiconfig` VALUES ('15', 'wechat_mchid', '', '受理商ID，身份标识');
INSERT INTO `mini_apiconfig` VALUES ('16', 'wechat_appkey', '', '商户支付密钥Key');
INSERT INTO `mini_apiconfig` VALUES ('17', 'wechat_appsecret', '', 'JSAPI接口中获取openid');
INSERT INTO `mini_apiconfig` VALUES ('18', 'wechat_token', '', '微信通讯token值');
INSERT INTO `mini_apiconfig` VALUES ('19', 'baidu_map_ak', '', '百度地图秘钥(ak)');
INSERT INTO `mini_apiconfig` VALUES ('20', 'baidu_map_lon', '', '中心点经度');
INSERT INTO `mini_apiconfig` VALUES ('21', 'baidu_map_lat', '', '中心点纬度');

-- -----------------------------
-- Table structure for `mini_banner`
-- -----------------------------
DROP TABLE IF EXISTS `mini_banner`;
CREATE TABLE `mini_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '' COMMENT '广告名称',
  `description` varchar(500) NOT NULL DEFAULT '' COMMENT '广告位置描述',
  `position` int(11) NOT NULL COMMENT '广告位置',
  `banner_path` varchar(140) NOT NULL COMMENT '图片地址',
  `link` varchar(140) NOT NULL DEFAULT '' COMMENT '连接地址',
  `level` int(4) NOT NULL DEFAULT '0' COMMENT '优先级',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（2：禁用 1：正常）',
  `createtime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- -----------------------------
-- Records of `mini_banner`
-- -----------------------------
INSERT INTO `mini_banner` VALUES ('1', 'banner图1', 'banner图1', '1', '/uploads/picture/20170330/da9448c8984d59b1b12472063f994c43.jpg', '#', '0', '1', '1474862526', '0');
INSERT INTO `mini_banner` VALUES ('2', 'banner图2', 'banner图2', '1', '/uploads/picture/20170330/e109223d06f0c4edc9195e61b282da40.jpg', '#', '0', '1', '1474862717', '0');
INSERT INTO `mini_banner` VALUES ('7', 'banner图3', 'banner图3', '1', '/uploads/picture/20170330/6ac502582f808cb85282562a95da76fb.jpg', '#', '0', '1', '1490774191', '0');

-- -----------------------------
-- Table structure for `mini_banner_position`
-- -----------------------------
DROP TABLE IF EXISTS `mini_banner_position`;
CREATE TABLE `mini_banner_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` char(80) NOT NULL,
  `width` char(20) NOT NULL,
  `height` char(20) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用 1：正常)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_banner_position`
-- -----------------------------
INSERT INTO `mini_banner_position` VALUES ('1', 'pc首页banner图', '1920', '600', '1');
INSERT INTO `mini_banner_position` VALUES ('2', '商品页推荐', '200', '260', '1');
INSERT INTO `mini_banner_position` VALUES ('3', 'wap首页焦点图', '', '', '1');
INSERT INTO `mini_banner_position` VALUES ('4', 'pc端单页广告', '1200', '139', '1');

-- -----------------------------
-- Table structure for `mini_business_need`
-- -----------------------------
DROP TABLE IF EXISTS `mini_business_need`;
CREATE TABLE `mini_business_need` (
  `name` char(128) NOT NULL COMMENT '姓名',
  `mobile` varchar(128) NOT NULL COMMENT '手机号',
  `wx` char(128) DEFAULT NULL COMMENT '微信号',
  `description` text COMMENT '备注',
  `createtime` int(11) NOT NULL,
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_business_need`
-- -----------------------------
INSERT INTO `mini_business_need` VALUES ('111111111', '2147483647', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('11111111', '2147483647', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('11111111', '2147483647', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('张辉', '13621093922', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('11111111', '13810773215', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('张辉', '13621093922', '', '', '0');
INSERT INTO `mini_business_need` VALUES ('aja', '13621093922', '', '', '0');

-- -----------------------------
-- Table structure for `mini_cart`
-- -----------------------------
DROP TABLE IF EXISTS `mini_cart`;
CREATE TABLE `mini_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '购买数量',
  `createtime` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1：正常，2：已购买',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_cart`
-- -----------------------------
INSERT INTO `mini_cart` VALUES ('56', '1', '45', '1', '1487299145', '1');

-- -----------------------------
-- Table structure for `mini_code`
-- -----------------------------
DROP TABLE IF EXISTS `mini_code`;
CREATE TABLE `mini_code` (
  `id` int(60) NOT NULL AUTO_INCREMENT,
  `mobile` char(128) DEFAULT NULL,
  `code` char(30) DEFAULT NULL,
  `yzm_time` int(60) DEFAULT NULL,
  `num` int(60) NOT NULL DEFAULT '0',
  `captcha` char(30) NOT NULL,
  `date` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_email_check`
-- -----------------------------
DROP TABLE IF EXISTS `mini_email_check`;
CREATE TABLE `mini_email_check` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `username` char(128) NOT NULL,
  `email` char(128) NOT NULL,
  `passtime` int(128) NOT NULL,
  `token` char(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_goods`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods`;
CREATE TABLE `mini_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT '商品名称',
  `num` int(11) NOT NULL COMMENT '商品库存数量',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `description` text NOT NULL COMMENT '商品描述',
  `man_profiles` text NOT NULL COMMENT '达人个人简介',
  `goods_profiles` text NOT NULL COMMENT '达人体验简介',
  `standard` varchar(255) NOT NULL COMMENT '规格型号',
  `cover_path` varchar(255) NOT NULL COMMENT '封面图',
  `photo_path_1` varchar(255) DEFAULT NULL,
  `photo_path_2` varchar(255) DEFAULT NULL,
  `photo_path_3` varchar(255) DEFAULT NULL,
  `content` text NOT NULL COMMENT '商品详情',
  `click_count` int(11) NOT NULL DEFAULT '0' COMMENT '商品点击数',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:上架，2：下架',
  `is_best` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为精品',
  `is_new` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为新品',
  `is_hot` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为热销',
  `sell_num` int(11) NOT NULL DEFAULT '0' COMMENT '已经出售的数量',
  `createtime` int(11) NOT NULL COMMENT '创建时间',
  `score_num` tinyint(2) NOT NULL DEFAULT '1' COMMENT '平均评分',
  `score` int(11) DEFAULT NULL COMMENT '积分',
  `label_tese` text NOT NULL COMMENT '特色标签',
  `label_quan` text NOT NULL COMMENT '券代标签',
  `label_area` text NOT NULL COMMENT '地区标签',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_goods`
-- -----------------------------
INSERT INTO `mini_goods` VALUES ('49', '1', 'c80ba331-9f0c-76f3-dc70-a64418255786', '紫大师的私人画廊与咖啡厅 ', '100', '5000.00', '山梨县的八岳山高原上有紫大师自己的画廊和咖啡厅，在这里不仅可以看到富士山，还能看到秩父山。', '', '', '', '/uploads/picture/20170330/1702bd27de1ff62683566d68a0620989.jpg', '/uploads/picture/20170330/5c32041cbb6656d8ffebefd09af3a916.jpg', '/uploads/picture/20170330/102870a6ef65ae6de9d3e523d3d67b27.jpg', '/uploads/picture/20170330/dc70b0c90309100053bbe79988f0edfe.jpg', '<p><span style="font-size: 20px;"><strong>达人介绍：</strong></span></p><p>日本著名艺术家，擅长使用紫色基调进行类似泼墨方式的绘画创作，被称为紫大师。他是日本山梨大学的客座教授，还是山东徐悲鸿艺术学院的名誉校长，被聘为山东国际文化交流中心副理事长。</p><p><strong><span style="font-size: 20px;">分享体验：</span></strong></p><p><strong><span style="font-size: 20px;"></span></strong></p><p>达人分享1：紫大师的私人画廊与咖啡厅 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>山梨县的八岳山高原上有紫大师自己的画廊和咖啡厅，在这里不仅可以看到富士山，还能看到秩父山，每到红叶季节，红叶、黄叶、常绿树交织而成的犹如一幅点描画在大地上徐徐舒展开来。眺望美丽的景色，欣赏着新月紫绀大的艺术作品，喝着浓郁的咖啡，共度梦幻时刻。 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p><p>达人分享2：紫大师的私人艺术交流 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>新月紫绀大非常愿意与国外的同行或者爱好者进行私下交流，视情况更可能亲自为您创作一幅属于您的作品，您动心了吗？</p><p><strong><span style="font-size: 20px;"><br/></span></strong><br/></p>', '0', '1', '0', '0', '1', '0', '1490885452', '1', '0', '山梨县|2小时', '代|', '山梨县');
INSERT INTO `mini_goods` VALUES ('50', '1', 'e52ab058-24dd-18d5-b3da-27bd51b92af2', '特色景点 | 旭山动物园', '100', '820.00', '日本最北端的动物园旭山动物园可以说是旭川的主要观光所。在日本算得上最有人气的动物园名列之一。', '', '', '', '/uploads/picture/20170330/3efcd58d57fbefc8c80f86ec8bde53a5.jpg', '/uploads/picture/20170330/ce83c2f95b5b1e5a495d17f35548dbcf.jpg', '/uploads/picture/20170330/43c3a9d737b30c8960419c83825904d5.jpg', '/uploads/picture/20170330/09c22a1369114c456b13768ddfe3caae.jpg', '<p><span style="font-size: 20px;"><strong>详情介绍：</strong></span></p><p>旭川位于北海道的正中，是仅次于札幌的北海道第二大城市。以雄伟的大雪山为背景，分布着大小 120 条河流，自然条件优越，还是去层云峡和富良野方向观光的大门。这里艺术活动十分频繁，有“艺术之城”之称，旭川车站前笔直延伸的和平大道购物公园里到处是喷泉和城市雕塑。&nbsp;</p><p>登上高岗可以饱览市容，这里有一个北海道传统美术工艺村，建筑物模仿中世纪欧洲的城堡，充满了娱乐场所的气氛。这里还有世界著名的阿伊努织物“优佳良织”的展览馆，能帮助游人加深了解日本的传统工艺。&nbsp;</p><p>日本最北端的动物园旭山动物园可以说是旭川的主要观光所。在日本算得上最有人气的动物园名列之一。动物园的主题观念是提供给所有的动物得到充分的放松，自由，发挥其最大的能力的生存环境。来客可看到北极熊潜水，海豹钻进狭窄的隧道游泳等等。</p><p>另外，旭川还是与札幌齐名的“拉面”（日本汤面）之城，拉面店数不胜数，生意兴隆。</p><p><span style="font-size: 20px;"><strong>开放时间：</strong></span></p><p>4月下旬 - 10月中旬&nbsp;</p><p>9:30 - 17:15 最晚入园时间：16:15截止</p><p>11月上旬 - 4月上旬&nbsp;</p><p>10:30&nbsp;-&nbsp;15:30 最晚入园时间：15:00截止</p><p><span style="font-size: 20px;"><strong>建议游览时长：</strong></span></p><p>3小时</p><p><span style="font-size: 20px;"><strong>地址：</strong></span></p><p>北海道旭川市東旭川町倉沼</p><p style="text-align:center"><img src="/uploads/editor/image/20170330/1490882408205034.jpg" title="1490882408205034.jpg" alt="10001.jpg"/></p><p><br/></p><p style="text-align:center"><img src="/uploads/editor/image/20170330/1490882446497513.jpg" title="1490882446497513.jpg" alt="yerongyechatu.jpg"/></p><p><br/></p><p><span style="font-size: 20px;"><strong>费用说明：</strong></span></p><p>轻定制的套餐起价为6人以内（含6人）3500元人民币起，7-12人（含12人）5500元人民币起，高于12人价格另行协商；</p><p>如您预订单独项目/酒店/车辆等收取服务费500元起；</p><p>套餐服务内容包括：日本专业团队行程规划、线下景点/体验代订、微信/电话24小时远程支持服务；</p><p>亲途承诺所有轻定制的景点/体验均为原始价格，可到达后向本地商家付款，我们也可以代付；</p><p>所有代订项目在距离达到的5个工作日以外大部分项目/酒店可免费取消，5个工作日内取消则退费用的50%；</p><p>更多详情可咨询亲途服务热线：4000-530-586。</p><p><br/></p><p><strong><span style="font-size: 20px;">常见问题：</span></strong></p><p>什么是轻定制？</p><p>轻定制是一种全新的体验，您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很</p><p>多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的</p><p>行程设计与代办费用。</p><p>如何提交我的心愿？</p><p>当您看到心仪的景点/体验内容点击”加入心愿单”会有提示框，如果继续添加其他内容直至满足您的旅行需求选择“继续逛逛”，当满足您的旅行需求</p><p>点击进入我的心愿单或点击我的旅行，进入后点击“提交我的全部心愿”之后在2小时内我们的客服人员会与您取的联系。</p><p>内容框里的“劵”“中”“代”是什么意思？</p><p>亲途所有的景点/体验跟线下相关关联，劵代表此项内容里本身含有折扣券，中代表当预订成功后提供电子中文手册发送至您的邮箱，代代表此项内容里</p><p>支持线下的代订服务。</p><p><br/></p>', '0', '1', '0', '0', '0', '0', '1490884233', '1', '0', '北海道|3小时|动物', '中|', '北海道');
INSERT INTO `mini_goods` VALUES ('51', '1', '2f4801e5-d4bb-4762-a998-1fb8a2aa0ca8', '妈妈达人 | 佳霖', '100', '5000.00', '创立美丽妈妈协会，并且出版了杂志《美丽mama》，深受妈妈们的好评。', '<h3>明星达人 佳霖</h3>
1999年，19岁的佳霖因为不甘自己的一生被父亲随随便便地安排，只身来到日本留学，攻读了明治大学研究院的工商管理修士学位。大学毕业以后，她先后进入房地产公司和广告公司工作，一路发扬在日本求学所培养出来的“燃”精神，一直做到Top sales，每个月的销售业绩都位居第一，不输于任何人。但就是这样一位优秀的员工，在2012年生下第一个女儿之后，在异国他乡的职场触到了无形的天花板：因为大家认为有孩子的女人不会把百分百的心思用于工作，所以不敢再轻易委以重任，只会发配给她一些几乎不能体现个人价值的无足轻重的工作。于是，在先生的鼓励下，她干脆咬牙辞职，开始了全心全意地育儿和创业生涯，她着手创立美丽妈妈协会，并且出版了面向在日华人女性的杂志《美丽mama》，深受妈妈们的好评。', '<h3>分享体验</h3>
达人分享1：美丽妈妈佳霖带您逛银座
佳霖的美丽妈妈协会办公室就在东京银座，每天都要在银座的高楼大厦里穿梭，如果您需要一位熟悉银座熟悉各种品牌的顾问的话，美丽妈妈佳霖就是最好的选择。
达人分享2：美丽妈妈协会的交流体验                                                                                
佳霖创办的美丽妈妈协会关注80后妈妈普遍所关注的问题，同时欢迎广大年轻妈妈们一起从属于日本的另一个角度交流经验，分享知识，喜欢分享的妈妈们不要犹豫赶快来吧！', '', '/uploads/picture/20170330/930ae97c53ac54b1b80e80c4a3ff4ff2.jpg', '/uploads/picture/20170330/60e17e6f08e8a10b5570ef7dfcb9fd2f.jpg', '/uploads/picture/20170330/59ce31f1972340d6c2b07935e2cb23e5.jpg', '/uploads/picture/20170330/6810bed2813dbc938e6e167125c78ebc.jpg', '<p><span style="font-size: 20px;"><strong>达人介绍：</strong></span></p><p>1999年，19岁的佳霖因为不甘自己的一生被父亲随随便便地安排，只身来到日本留学，攻读了明治大学研究院的工商管理修士学位。大学毕业以后，她先后进入房地产公司和广告公司工作，一路发扬在日本求学所培养出来的“燃”精神，一直做到Top sales，每个月的销售业绩都位居第一，不输于任何人。但就是这样一位优秀的员工，在2012年生下第一个女儿之后，在异国他乡的职场触到了无形的天花板：因为大家认为有孩子的女人不会把百分百的心思用于工作，所以不敢再轻易委以重任，只会发配给她一些几乎不能体现个人价值的无足轻重的工作。于是，在先生的鼓励下，她干脆咬牙辞职，开始了全心全意地育儿和创业生涯，她着手创立美丽妈妈协会，并且出版了面向在日华人女性的杂志《美丽mama》，深受妈妈们的好评。</p><p><span style="font-size: 20px;"><strong>分享体验：</strong></span></p><p>达人分享1：美丽妈妈佳霖带您逛银座 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>佳霖的美丽妈妈协会办公室就在东京银座，每天都要在银座的高楼大厦里穿梭，如果您需要一位熟悉银座熟悉各种品牌的顾问的话，美丽妈妈佳霖就是最好的选择。 达人分享2：美丽妈妈协会的交流体验 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>佳霖创办的美丽妈妈协会关注80后妈妈普遍所关注的问题，同时欢迎广大年轻妈妈们一起从属于日本的另一个角度交流经验，分享知识，喜欢分享的妈妈们不要犹豫赶快来吧！</p><p><strong><span style="font-size: 20px;">预约时间：</span></strong></p><p><span style="font-size: 16px;">如果对佳霖的分享感兴趣请在提前15个工作日向亲途预约。</span></p>', '0', '1', '1', '0', '1', '0', '1490886860', '1', '0', '东京|8小时|年轻妈妈', '代|', '东京');
INSERT INTO `mini_goods` VALUES ('52', '1', '020cabfb-df70-70b1-a71d-5d2a2e88cb0f', '日本民俗之旅', '100', '0.01', '主题定制1', '', '', '', '/uploads/picture/20170330/570e1c54336319364445f9eb77c57384.jpg', '', '', '', '<p>主题定制1</p>', '0', '1', '0', '0', '1', '0', '1490875518', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('53', '1', '837a87e0-8fd7-0e48-4f3a-b6f9d271e297', '分享旅行体验', '100', '0.01', '开启分享旅行全新模式，让各行各业通晓中文的精英为您提供私人导游陪同服务。', '', '', '', '/uploads/picture/20170330/df3502981b822fd3faaa74790b35c33a.jpg', '', '', '', '<p>111</p>', '0', '1', '0', '0', '1', '0', '1490888316', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('54', '1', '2eb86135-fb36-3e9c-a5ea-ab2137e2ad44', '健康体检之旅', '100', '12345.00', '主题定制2', '', '', '', '/uploads/picture/20170330/598cc3d63fe3d0e99d0c9addf22b8ca0.jpg', '', '', '', '<p>主题定制2</p>', '0', '1', '0', '0', '1', '0', '1490875555', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('55', '1', '578f8609-c756-e570-f1be-5b03ff93c6d5', '二次元世界之旅', '100', '1.00', '二次元世界之旅', '', '', '', '/uploads/picture/20170330/f085897dd507db3df0342bfeca644402.jpg', '', '', '', '', '0', '1', '0', '0', '0', '0', '1490875713', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('56', '1', '59a88608-deb5-961a-2ab0-9500a7150eb4', '传统美食之旅', '100', '1.00', '传统美食之旅', '', '', '', '/uploads/picture/20170330/af21fc2be5d622658266887449cc85e8.jpg', '', '', '', '', '0', '1', '0', '0', '0', '0', '1490875810', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('57', '1', '8a0e03fb-f90a-9944-354b-ac4897c1f48f', '摄影体验之旅', '100', '1.00', '摄影体验之旅', '', '', '', '/uploads/picture/20170330/159c901195b48ea4f5cddaeb89b92df0.jpg', '', '', '', '', '0', '1', '0', '0', '1', '0', '1490877891', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('58', '1', '0b039b5e-b244-3781-0f73-bb3361b4e8c2', '寻找灵气之旅', '100', '28880.00', '日本文化，国运发源之路，熊野古道几千年了，不知有多少故事，吸一口气就感觉要飞起来', '', '', '', '/uploads/picture/20170330/b59cf51a62ea0591a1db58a2e2d24bc4.jpg', '', '', '', '', '0', '1', '0', '0', '0', '0', '1490875944', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('60', '1', '1277f934-64ca-a86c-8891-15c3baabfec7', '艺术达人 | 新月紫绀大', '100', '5000.00', '日本著名艺术家，擅长使用紫色基调进行类似泼墨方式的绘画创作。', '<h3>明星达人 新月紫绀大</h3>
日本著名艺术家，擅长使用紫色基调进行类似泼墨方式的绘画创作，被称为紫大师。他是日本山梨大学的客座教授，还是山东徐悲鸿艺术学院的名誉校长，被聘为山东国际文化交流中心副理事长。', '<h3>分享体验</h3>
达人分享1：紫大师的私人画廊与咖啡厅
山梨县的八岳山高原上有紫大师自己的画廊和咖啡厅，在这里不仅可以看到富士山，还能看到秩父山，每到红叶季节，红叶、黄叶、常绿树交织而成的犹如一幅点描画在大地上徐徐舒展开来。眺望美丽的景色，欣赏着新月紫绀大的艺术作品，喝着浓郁的咖啡，共度梦幻时刻。                         
达人分享2：紫大师的私人艺术交流
 新月紫绀大非常愿意与国外的同行或者爱好者进行私下交流，视情况更可能亲自为您创作一幅属于您的作品，您动心了吗？', '', '/uploads/picture/20170330/d6f1b58e1ee5934834d1dde0a22abfba.jpg', '/uploads/picture/20170330/dbf0dd95bb0693d8ea6a30ea3738102f.jpg', '/uploads/picture/20170330/5ebf4d13cb344cbd160f1a846b672379.jpg', '/uploads/picture/20170330/c1860c8ccdffc6293bc3f242e85d9e46.jpg', '<p><strong><span style="font-size: 20px;">达人介绍：</span></strong></p><p>日本著名艺术家，擅长使用紫色基调进行类似泼墨方式的绘画创作，被称为紫大师。他是日本山梨大学的客座教授，还是山东徐悲鸿艺术学院的名誉校长，被聘为山东国际文化交流中心副理事长。</p><p><span style="font-size: 20px;"><strong>达人分享：</strong></span></p><p><span style="font-size: 20px;"></span></p><p>达人分享1：紫大师的私人画廊与咖啡厅 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>山梨县的八岳山高原上有紫大师自己的画廊和咖啡厅，在这里不仅可以看到富士山，还能看到秩父山，每到红叶季节，红叶、黄叶、常绿树交织而成的犹如一幅点描画在大地上徐徐舒展开来。眺望美丽的景色，欣赏着新月紫绀大的艺术作品，喝着浓郁的咖啡，共度梦幻时刻。 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p><p>达人分享2：紫大师的私人艺术交流 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>新月紫绀大非常愿意与国外的同行或者爱好者进行私下交流，视情况更可能亲自为您创作一幅属于您的作品，您动心了吗？</p><p><strong><span style="font-size: 20px;">预约时间：</span></strong></p><p><span style="font-size: 16px;">需提前10个工作日预约。</span><br/></p>', '0', '1', '1', '0', '0', '0', '1490918388', '1', '0', '山梨县|2小时|艺术', '代|', '山梨县');
INSERT INTO `mini_goods` VALUES ('62', '1', '93f9d63f-0cd4-2fb3-dd45-d8257d2ae695', '特色景点 | 函馆山', '100', '1280.00', '函馆市位于北海道南部、渡岛半岛的尖端，与香港和那不勒斯并称为“世界三大夜景”的函馆夜景。', '', '', '', '/uploads/picture/20170330/31cd8f9cea06ef7f0c8dc8efaebb8142.jpg', '/uploads/picture/20170330/a37cd5e88d3638f3563ebe33143a2a23.jpg', '/uploads/picture/20170330/13f725d570a30b487a43ad7a4e099abc.jpg', '/uploads/picture/20170330/4dfee167669caa6af85df2bdc09365bc.jpg', '<p style="white-space: normal;"><span style="font-size: 20px;"><strong>详情介绍：</strong></span></p><p>函馆市位于北海道南部、渡岛半岛的尖端，市的近郊风景胜地云集。位于函馆市西南、遥望津轻海峡的函馆山因形似卧倒的牛，所以被称为卧牛山，全长835米的架空索道可以把游客带到海拔332 米高的山顶上。从全天候型的了望台上可以眺望函馆港与街市，南至下北半岛、津轻半岛都能尽收眼底。与香港和那不勒斯并称为“世界三大夜景”的函馆夜景，配上海上隐约可见的渔火，堪称为人间一大绝景。</p><p>从函馆车站乘坐巴士 30分钟处有特拉比斯奇奴修道院，是1898 年由法国派遣来日本的8名修女创建的，可以公开参观竖立着圣母玛利亚像与贞德像的前庭。</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>开放时间：</strong></span></p><p style="white-space: normal;">晚上</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>建议游览时长：</strong></span></p><p style="white-space: normal;">1小时</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>地址：</strong></span></p><p style="white-space: normal;">北海道函館市函館山</p><p style="white-space: normal; text-align: center;"><img src="/uploads/editor/image/20170330/1490883159109013.jpg" title="1490883159109013.jpg" alt="10002.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal; text-align: center;"><img src="http://www.kintou.net/uploads/editor/image/20170330/1490882446497513.jpg" title="1490882446497513.jpg" alt="yerongyechatu.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>费用说明：</strong></span></p><p style="white-space: normal;">轻定制的套餐起价为6人以内（含6人）3500元人民币起，7-12人（含12人）5500元人民币起，高于12人价格另行协商；</p><p style="white-space: normal;">如您预订单独项目/酒店/车辆等收取服务费500元起；</p><p style="white-space: normal;">套餐服务内容包括：日本专业团队行程规划、线下景点/体验代订、微信/电话24小时远程支持服务；</p><p style="white-space: normal;">亲途承诺所有轻定制的景点/体验均为原始价格，可到达后向本地商家付款，我们也可以代付；</p><p style="white-space: normal;">所有代订项目在距离达到的5个工作日以外大部分项目/酒店可免费取消，5个工作日内取消则退费用的50%；</p><p style="white-space: normal;">更多详情可咨询亲途服务热线：4000-530-586。</p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><strong><span style="font-size: 20px;">常见问题：</span></strong></p><p style="white-space: normal;">什么是轻定制？</p><p style="white-space: normal;">轻定制是一种全新的体验，您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很</p><p style="white-space: normal;">多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的</p><p style="white-space: normal;">行程设计与代办费用。</p><p style="white-space: normal;">如何提交我的心愿？</p><p style="white-space: normal;">当您看到心仪的景点/体验内容点击”加入心愿单”会有提示框，如果继续添加其他内容直至满足您的旅行需求选择“继续逛逛”，当满足您的旅行需求</p><p style="white-space: normal;">点击进入我的心愿单或点击我的旅行，进入后点击“提交我的全部心愿”之后在2小时内我们的客服人员会与您取的联系。</p><p style="white-space: normal;">内容框里的“劵”“中”“代”是什么意思？</p><p style="white-space: normal;">亲途所有的景点/体验跟线下相关关联，劵代表此项内容里本身含有折扣券，中代表当预订成功后提供电子中文手册发送至您的邮箱，代代表此项内容里</p><p style="white-space: normal;">支持线下的代订服务。</p><p><br/></p>', '0', '1', '0', '0', '0', '0', '1490884218', '1', '0', '北海道|1小时|景色', '', '北海道');
INSERT INTO `mini_goods` VALUES ('63', '1', '08cd6c37-6a56-ee23-2f18-36f86c461748', '特色景点 | 神威岬', '100', '0.10', '从黄金岬到积丹岬和神威岬一带是北海道唯一的海上公园。您到了此处一定会觉得不枉此行！', '', '', '', '/uploads/picture/20170330/98534138c41143bce76fc96f3be9c4bf.jpg', '/uploads/picture/20170330/bccc643bb772ddc008ba50899bada5df.jpg', '/uploads/picture/20170330/d6683eb8296a6579a6aca979760475b7.jpg', '/uploads/picture/20170330/8f33b7a36a9c1477cb35da8953b1a515.jpg', '<p style="white-space: normal;"><span style="font-size: 20px;"><strong>详情介绍：</strong></span></p><p style="white-space: normal;">景如其名，神威岬位于北海道西部，属于伸向日本海的积丹半岛，非常漂亮，海水澄碧，海岸线曲折多变，从黄金岬到积丹岬和神威岬一带是北海道唯一的海上公园。您到了此处一定会觉得不枉此行！</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>开放时间：</strong></span></p><p style="white-space: normal;">白天</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>建议游览时长：</strong></span></p><p style="white-space: normal;">2小时</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>地址：</strong></span></p><p style="white-space: normal;">北海道積丹郡積丹町神岬</p><p style="white-space: normal; text-align: center;"><img src="/uploads/editor/image/20170330/1490883374165022.jpg" title="1490883374165022.jpg" alt="10003.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal; text-align: center;"><img src="http://www.kintou.net/uploads/editor/image/20170330/1490882446497513.jpg" title="1490882446497513.jpg" alt="yerongyechatu.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>费用说明：</strong></span></p><p style="white-space: normal;">轻定制的套餐起价为6人以内（含6人）3500元人民币起，7-12人（含12人）5500元人民币起，高于12人价格另行协商；</p><p style="white-space: normal;">如您预订单独项目/酒店/车辆等收取服务费500元起；</p><p style="white-space: normal;">套餐服务内容包括：日本专业团队行程规划、线下景点/体验代订、微信/电话24小时远程支持服务；</p><p style="white-space: normal;">亲途承诺所有轻定制的景点/体验均为原始价格，可到达后向本地商家付款，我们也可以代付；</p><p style="white-space: normal;">所有代订项目在距离达到的5个工作日以外大部分项目/酒店可免费取消，5个工作日内取消则退费用的50%；</p><p style="white-space: normal;">更多详情可咨询亲途服务热线：4000-530-586。</p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><strong><span style="font-size: 20px;">常见问题：</span></strong></p><p style="white-space: normal;">什么是轻定制？</p><p style="white-space: normal;">轻定制是一种全新的体验，您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很</p><p style="white-space: normal;">多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的</p><p style="white-space: normal;">行程设计与代办费用。</p><p style="white-space: normal;">如何提交我的心愿？</p><p style="white-space: normal;">当您看到心仪的景点/体验内容点击”加入心愿单”会有提示框，如果继续添加其他内容直至满足您的旅行需求选择“继续逛逛”，当满足您的旅行需求</p><p style="white-space: normal;">点击进入我的心愿单或点击我的旅行，进入后点击“提交我的全部心愿”之后在2小时内我们的客服人员会与您取的联系。</p><p style="white-space: normal;">内容框里的“劵”“中”“代”是什么意思？</p><p style="white-space: normal;">亲途所有的景点/体验跟线下相关关联，劵代表此项内容里本身含有折扣券，中代表当预订成功后提供电子中文手册发送至您的邮箱，代代表此项内容里</p><p style="white-space: normal;">支持线下的代订服务。</p><p><br/></p>', '0', '1', '0', '0', '0', '0', '1490884204', '1', '0', '北海道|2小时|景色', '', '');
INSERT INTO `mini_goods` VALUES ('64', '1', '97ec253c-d1a9-d03b-29c0-04b9a6a482bb', '特色体验 | 札幌雪橇', '100', '5800.00', '同样在冬季流行的狗拉雪橇体验，3岁以上的小孩也可以一起体验!', '', '', '', '/uploads/picture/20170330/f5abc81a38640245343414d6672d35b2.jpg', '/uploads/picture/20170330/cc9a12b190581e20a3ada40bf132c2f6.jpg', '/uploads/picture/20170330/e68c56e5e8febf02dde68271e9440c0a.jpg', '/uploads/picture/20170330/1a21b2f3ac3a94442ededb1a31c18d3f.jpg', '<p style="white-space: normal;"><span style="font-size: 20px;"><strong>详情介绍：</strong></span></p><p style="white-space: normal;">同样在冬季流行的狗拉雪橇体验，3岁以上的小孩也可以一起体验！</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>开放时间：</strong></span></p><p style="white-space: normal;">01月07日 - 03月20日&nbsp;</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>建议游览时长：</strong></span></p><p style="white-space: normal;">40分钟</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>地址：</strong></span></p><p style="white-space: normal;">北海道札幌市南区豊滝469-1</p><p style="white-space: normal; text-align: center;"><img src="/uploads/editor/image/20170330/1490884040691838.jpg" title="1490884040691838.jpg" alt="11002.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal; text-align: center;"><img src="http://www.kintou.net/uploads/editor/image/20170330/1490882446497513.jpg" title="1490882446497513.jpg" alt="yerongyechatu.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>费用说明：</strong></span></p><p style="white-space: normal;">轻定制的套餐起价为6人以内（含6人）3500元人民币起，7-12人（含12人）5500元人民币起，高于12人价格另行协商；</p><p style="white-space: normal;">如您预订单独项目/酒店/车辆等收取服务费500元起；</p><p style="white-space: normal;">套餐服务内容包括：日本专业团队行程规划、线下景点/体验代订、微信/电话24小时远程支持服务；</p><p style="white-space: normal;">亲途承诺所有轻定制的景点/体验均为原始价格，可到达后向本地商家付款，我们也可以代付；</p><p style="white-space: normal;">所有代订项目在距离达到的5个工作日以外大部分项目/酒店可免费取消，5个工作日内取消则退费用的50%；</p><p style="white-space: normal;">更多详情可咨询亲途服务热线：4000-530-586。</p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><strong><span style="font-size: 20px;">常见问题：</span></strong></p><p style="white-space: normal;">什么是轻定制？</p><p style="white-space: normal;">轻定制是一种全新的体验，您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很</p><p style="white-space: normal;">多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的</p><p style="white-space: normal;">行程设计与代办费用。</p><p style="white-space: normal;">如何提交我的心愿？</p><p style="white-space: normal;">当您看到心仪的景点/体验内容点击”加入心愿单”会有提示框，如果继续添加其他内容直至满足您的旅行需求选择“继续逛逛”，当满足您的旅行需求</p><p style="white-space: normal;">点击进入我的心愿单或点击我的旅行，进入后点击“提交我的全部心愿”之后在2小时内我们的客服人员会与您取的联系。</p><p style="white-space: normal;">内容框里的“劵”“中”“代”是什么意思？</p><p style="white-space: normal;">亲途所有的景点/体验跟线下相关关联，劵代表此项内容里本身含有折扣券，中代表当预订成功后提供电子中文手册发送至您的邮箱，代代表此项内容里</p><p style="white-space: normal;">支持线下的代订服务。</p><p><br/></p>', '0', '1', '0', '0', '0', '0', '1490884161', '1', '0', '北海道|40分|户外', '代|', '');
INSERT INTO `mini_goods` VALUES ('65', '1', 'a2958fb0-98ba-0f34-9336-024f74f17427', '特色景点 | 登别温泉', '100', '0.10', '为北海道有代表性的温泉而闻名的登别温泉海拔 200 米左右，是原始森林环抱的温泉疗养地。', '', '', '', '/uploads/picture/20170330/c4775c55fcbc56dc40a8a20d0fa00294.jpg', '/uploads/picture/20170330/6186cc7e609a59c2d494587799c1b945.JPG', '/uploads/picture/20170330/28e9a96a3a2711f338b6117c44d8cf85.jpg', '/uploads/picture/20170330/6f4fa3e8bf4f0948c63af3e9cc882adb.jpg', '<p style="white-space: normal;"><span style="font-size: 20px;"><strong>详情介绍：</strong></span></p><p>为北海道有代表性的温泉而闻名的登别温泉海拔 200 米左右，是原始森林环抱的温泉疗养地。这里九种温泉各具特色，有的是硫化氢水质，有的是食盐水质，有的则含铁。水质优良，已被列为世界珍稀温泉之一。</p><p>温泉中给人印象最深的是地狱谷，火山气体从灰黄色的岩石表面向外喷出，周围空气中充满了浓烈的硫磺异味，简直是一幅地狱中的景象。山谷是直径为 450 米的爆裂火口，温泉的出水量每分钟高达 3000 立升。</p><p>温泉东北部是登别原始森林，这里以水枹树、熊屉为中心，混生着各种阔叶树，已被指定为天然纪念物。耸立在东边的四方岭有养熊场，可以见到黑棕熊。从山顶望去，透明度为日本第 2，湖水澄碧的俱多乐湖也是一道景观。</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>开放时间：</strong></span></p><p style="white-space: normal;">全天</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>建议游览时长：</strong></span></p><p style="white-space: normal;">一天</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>地址：</strong></span></p><p style="white-space: normal;">北海道登別市登別温泉町</p><p style="white-space: normal; text-align: center;"><img src="/uploads/editor/image/20170330/1490884466346635.jpg" title="1490884466346635.jpg" alt="10004.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal; text-align: center;"><img src="http://www.kintou.net/uploads/editor/image/20170330/1490882446497513.jpg" title="1490882446497513.jpg" alt="yerongyechatu.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>费用说明：</strong></span></p><p style="white-space: normal;">轻定制的套餐起价为6人以内（含6人）3500元人民币起，7-12人（含12人）5500元人民币起，高于12人价格另行协商；</p><p style="white-space: normal;">如您预订单独项目/酒店/车辆等收取服务费500元起；</p><p style="white-space: normal;">套餐服务内容包括：日本专业团队行程规划、线下景点/体验代订、微信/电话24小时远程支持服务；</p><p style="white-space: normal;">亲途承诺所有轻定制的景点/体验均为原始价格，可到达后向本地商家付款，我们也可以代付；</p><p style="white-space: normal;">所有代订项目在距离达到的5个工作日以外大部分项目/酒店可免费取消，5个工作日内取消则退费用的50%；</p><p style="white-space: normal;">更多详情可咨询亲途服务热线：4000-530-586。</p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><strong><span style="font-size: 20px;">常见问题：</span></strong></p><p style="white-space: normal;">什么是轻定制？</p><p style="white-space: normal;">轻定制是一种全新的体验，您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很</p><p style="white-space: normal;">多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的</p><p style="white-space: normal;">行程设计与代办费用。</p><p style="white-space: normal;">如何提交我的心愿？</p><p style="white-space: normal;">当您看到心仪的景点/体验内容点击”加入心愿单”会有提示框，如果继续添加其他内容直至满足您的旅行需求选择“继续逛逛”，当满足您的旅行需求</p><p style="white-space: normal;">点击进入我的心愿单或点击我的旅行，进入后点击“提交我的全部心愿”之后在2小时内我们的客服人员会与您取的联系。</p><p style="white-space: normal;">内容框里的“劵”“中”“代”是什么意思？</p><p style="white-space: normal;">亲途所有的景点/体验跟线下相关关联，劵代表此项内容里本身含有折扣券，中代表当预订成功后提供电子中文手册发送至您的邮箱，代代表此项内容里</p><p style="white-space: normal;">支持线下的代订服务。</p><p><br/></p>', '0', '1', '0', '0', '0', '0', '1490884895', '1', '0', '北海道|一天|温泉', '中|代', '北海道');
INSERT INTO `mini_goods` VALUES ('66', '1', '29f73ca9-252b-c746-4f73-8b99792e5121', '特色景点 | 富良野', '100', '0.10', '“富良野”来自阿伊努语，有“芬芳的火炎”之意，为纪念市政 80 周年，建造了高山道路富良野薰衣草森林。', '', '', '', '/uploads/picture/20170330/e263c02eea41687a7e95d26e457991f5.jpg', '/uploads/picture/20170330/f7d9c73ae80d906c73a417f35cd0696d.jpg', '/uploads/picture/20170330/e6319193bacfc25b8be3c2b6aad4dfa6.jpg', '/uploads/picture/20170330/d6f290b3ecb8b8a1af3a0247994b80a1.jpg', '<p style="white-space: normal;"><span style="font-size: 20px;"><strong>详情介绍：</strong></span></p><p>富良野有绚烂多彩的四季，冬天水蒸气结成的水珠晶莹闪亮，春天路边到处盛开着观音莲，夏日有芬芳的薰衣草，秋日有满山的红叶。地名“富良野”来自阿伊努语，有“芬芳的火炎”之意。为纪念市政 80 周年，建造了高山道路富良野薰衣草森林，这里夏天鲜花盛开，林中一条充满淡淡花香的小道是颇受欢迎的散步场所。</p><p>另外，还有高山观光者中心，这里可以在空知川河上进行多种户外训练、钻水、乘坐热气球等，领略以富良野大自然为舞台的各种室外体育活动的乐趣，它和北之峰滑雪场都是旅游热点，终年游人不断。</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>开放时间：</strong></span></p><p>7，8月白天</p><p>営業：8:30～18:00 花人の舎、4月下旬～9月</p><p>営業：9:00～16:30 花人の舎、10月～4月中旬</p><p>営業：8:30～17:00 ポプリの舎、4月下旬～10月</p><p>営業：8:30～17:00 蒸留の舎、香水の舎、4月下旬～9月</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>建议游览时长：</strong></span></p><p style="white-space: normal;">2小时</p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>地址：</strong></span></p><p style="white-space: normal;">北海道空知郡中富良野町基線北15号</p><p style="white-space: normal; text-align: center;"><img src="/uploads/editor/image/20170330/1490884783275419.jpg" title="1490884783275419.jpg" alt="10005.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal; text-align: center;"><img src="http://www.kintou.net/uploads/editor/image/20170330/1490882446497513.jpg" title="1490882446497513.jpg" alt="yerongyechatu.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><span style="font-size: 20px;"><strong>费用说明：</strong></span></p><p style="white-space: normal;">轻定制的套餐起价为6人以内（含6人）3500元人民币起，7-12人（含12人）5500元人民币起，高于12人价格另行协商；</p><p style="white-space: normal;">如您预订单独项目/酒店/车辆等收取服务费500元起；</p><p style="white-space: normal;">套餐服务内容包括：日本专业团队行程规划、线下景点/体验代订、微信/电话24小时远程支持服务；</p><p style="white-space: normal;">亲途承诺所有轻定制的景点/体验均为原始价格，可到达后向本地商家付款，我们也可以代付；</p><p style="white-space: normal;">所有代订项目在距离达到的5个工作日以外大部分项目/酒店可免费取消，5个工作日内取消则退费用的50%；</p><p style="white-space: normal;">更多详情可咨询亲途服务热线：4000-530-586。</p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><strong><span style="font-size: 20px;">常见问题：</span></strong></p><p style="white-space: normal;">什么是轻定制？</p><p style="white-space: normal;">轻定制是一种全新的体验，您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很</p><p style="white-space: normal;">多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的</p><p style="white-space: normal;">行程设计与代办费用。</p><p style="white-space: normal;">如何提交我的心愿？</p><p style="white-space: normal;">当您看到心仪的景点/体验内容点击”加入心愿单”会有提示框，如果继续添加其他内容直至满足您的旅行需求选择“继续逛逛”，当满足您的旅行需求</p><p style="white-space: normal;">点击进入我的心愿单或点击我的旅行，进入后点击“提交我的全部心愿”之后在2小时内我们的客服人员会与您取的联系。</p><p style="white-space: normal;">内容框里的“劵”“中”“代”是什么意思？</p><p style="white-space: normal;">亲途所有的景点/体验跟线下相关关联，劵代表此项内容里本身含有折扣券，中代表当预订成功后提供电子中文手册发送至您的邮箱，代代表此项内容里</p><p style="white-space: normal;">支持线下的代订服务。</p><p><br/></p>', '0', '1', '0', '0', '0', '0', '1490884862', '1', '0', '北海道|2小时|美景', '', '北海道');
INSERT INTO `mini_goods` VALUES ('67', '1', 'cd431991-a7a4-3eb0-bcfd-9b3258e86aa8', '美丽妈妈佳霖带您逛银座 ', '100', '5000.00', '佳霖的美丽妈妈协会办公室就在东京银座，每天都要在银座的高楼大厦里穿梭。', '', '', '', '/uploads/picture/20170330/76d2c0be03f47dce74dc6aca7faeadb0.jpg', '/uploads/picture/20170330/bc772b06d62c366f0c4999e593e9b984.jpg', '/uploads/picture/20170330/ca31e965ed63b53508a7880f1e84bc97.jpg', '/uploads/picture/20170330/169a93cabd94e235765f0bb362e694bc.jpg', '<p><span style="font-size: 20px;"><strong>达人介绍</strong></span></p><p>1999年，19岁的佳霖因为不甘自己的一生被父亲随随便便地安排，只身来到日本留学，攻读了明治大学研究院的工商管理修士学位。大学毕业以后，她先后进入房地产公司和广告公司工作，一路发扬在日本求学所培养出来的“燃”精神，一直做到Top sales，每个月的销售业绩都位居第一，不输于任何人。但就是这样一位优秀的员工，在2012年生下第一个女儿之后，在异国他乡的职场触到了无形的天花板：因为大家认为有孩子的女人不会把百分百的心思用于工作，所以不敢再轻易委以重任，只会发配给她一些几乎不能体现个人价值的无足轻重的工作。于是，在先生的鼓励下，她干脆咬牙辞职，开始了全心全意地育儿和创业生涯，她着手创立美丽妈妈协会，并且出版了面向在日华人女性的杂志《美丽mama》，深受妈妈们的好评。</p><p><strong><span style="font-size: 20px;">分享体验：</span></strong></p><p>达人分享1：美丽妈妈佳霖带您逛银座 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>佳霖的美丽妈妈协会办公室就在东京银座，每天都要在银座的高楼大厦里穿梭，如果您需要一位熟悉银座熟悉各种品牌的顾问的话，美丽妈妈佳霖就是最好的选择。 达人分享2：美丽妈妈协会的交流体验 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>佳霖创办的美丽妈妈协会关注80后妈妈普遍所关注的问题，同时欢迎广大年轻妈妈们一起从属于日本的另一个角度交流经验，分享知识，喜欢分享的妈妈们不要犹豫赶快来吧！</p><p><span style="font-size: 20px;"><strong>体验预约：</strong></span></p><p>需提前15个工作日</p>', '0', '1', '0', '0', '1', '0', '1490885577', '1', '0', '东京|8小时', '代|', '东京');
INSERT INTO `mini_goods` VALUES ('68', '1', '619bba9c-3679-dbbb-3343-535958c8dca4', '健康长寿日本家常菜讲座 ', '100', '4000.00', '安良木先生教您如何利用中国的食材来简单快捷制作日本家常菜。', '', '', '', '/uploads/picture/20170330/ae34da2122153f6d212775fe8221c90e.jpg', '/uploads/picture/20170330/46c0af53c2586a3a5c2fc8bf1eb49683.jpg', '/uploads/picture/20170330/b7191988d1ffcf8adff6e7400e679927.jpg', '/uploads/picture/20170330/a78804b52e13f31460e078bc79248375.jpg', '<p><span style="font-size: 20px;"><strong>达人介绍：</strong></span></p><p>安良木 海山1949年在长崎出生，美国宾夕法尼亚大学毕业，历任知名日企的驻美驻欧负责人。</p><p>1996年至2016年在香港和中国工作生活，参加过中国的嘉里中心和新天地的开发项目并在中国东北某城市创立了当地首家日本料理店。2016年回日本东京定居。</p><p><strong><span style="font-size: 20px;">分享体验：</span></strong></p><p>日本的家常菜简单方便，营养搭配协调。安良木先生协在中国开办日本家常菜馆的经验，教您如何利用中国的食材来简单快捷制作烧乌冬，日式咖喱，小菜酱汤等。</p><p>让您可以有的放矢在日本超市采购调味品带回，也可以当场购买。日本家庭料理由于其健康元素，使得日本人普遍健康寿命很长，还犹豫什么呢，赶紧来体验吧！</p><p><span style="font-size: 20px;"><strong>体验预约：</strong></span></p><p>需提前20个工作日</p><p><br/></p>', '0', '1', '0', '0', '1', '0', '1490885820', '1', '0', '东京|2小时|手艺', '代|', '东京');
INSERT INTO `mini_goods` VALUES ('69', '1', '67fecaf0-1366-ae9f-3bfd-5914c0f8d44b', '音乐达人 | 滨边良信', '100', '8750.00', '滨边大学毕业后进入演艺界，表演过话剧，做过音乐艺人的经纪人。', '', '', '', '/uploads/picture/20170330/9170872e1e4ac220bdd93bcd05201a89.jpg', '/uploads/picture/20170330/640ccf025fa18509c2bb9865bc086a3d.jpg', '/uploads/picture/20170330/e824cb14b05ca1fc1bf6fdf816b5253e.jpg', '/uploads/picture/20170330/63690c1c8587a1b9aecbce39d111565b.jpg', '<p><strong><span style="font-size: 20px;">达人介绍：</span></strong></p><p>日本创价学会大学毕业，后进入演艺界，表演过话剧，做过音乐艺人的经纪人，还担任过众多电视节目的制片人。近20年来一直生活在中国人聚集的池袋，特别是为池袋地区的有线电视台做过电视节目。</p><p><strong><span style="font-size: 20px;">分享体验：</span></strong></p><p>东瀛音乐之旅 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;滨边对池袋地区的各种店铺，各种商业设施如数家珍。虽然中文不是特别溜，如果您需要一位池袋的向导，他一定是最合适的。但关键不在于此，滨边是日本资深制片人,以及音乐经纪人，如果您对日本的演艺圈特别是音乐圈感兴趣，滨边会为您娓娓道来，并根据您的需求，为您架起与日本音乐界的交流桥梁。如果各项条件许可的话，或许还能带您去电视拍摄，音乐制作现场探访哦。</p><p><strong><span style="font-size: 20px;">预约时间：</span></strong></p><p><span style="font-size: 16px;">需提前20个工作日预约</span></p>', '0', '1', '0', '0', '1', '0', '1490886935', '1', '0', '池袋|10小时|音乐', '代|', '');
INSERT INTO `mini_goods` VALUES ('70', '1', '3f29df32-f40d-54ed-2537-3330218810d0', '明星私导 | 水谷浩', '100', '80000.00', '2006年成为专职翻译和导游，现在为日本中文导游协会副会长。', '', '', '', '/uploads/picture/20170330/e47f6668a671ba50616e14533ec99b7e.jpg', '', '', '', '<p><strong><span style="font-size: 20px;">私导介绍：</span></strong></p><p>1957年大阪出生，80年代北京大学留学，后从事船舶制造等工作，2006年成为专职翻译和导游。现在为日本中文导游协会副会长。擅长的翻译领域有机械，电器，钢铁，金属，建筑以及环保。学生时代一直喜爱垂钓，担任过全日本学生钓鱼联盟的常务理事，所以很愿意领着中国游客在日本的湖泊里体验钓鱼的乐趣。</p><p>对大阪，奈良和京都为中心的关西地区了如指掌，如果您想深度游日本的话，水谷先生无疑是您的良师益友。</p><p><strong><span style="font-size: 20px;">预约时间：</span></strong></p><p>请提前15个工作日预约</p><p><br/></p>', '0', '1', '0', '0', '1', '0', '1490887171', '1', '0', '关西|8小时|关西', '代|', '关西');
INSERT INTO `mini_goods` VALUES ('71', '1', '8fd82806-3077-dda0-74ef-b9c0f1acc6d5', '明星私导 | 秋泽文芳', '100', '80000.00', '中日恢复邦交正常化35周年时，作为中日政府旅游业务的交流窗口。', '', '', '', '/uploads/picture/20170330/7af6975237b14a7e6e7ffde8d1a42a5e.jpg', '', '', '', '<p><span style="font-size: 20px;"><strong>私导介绍：</strong></span></p><p>千叶大学毕业后进入旅游业，后有机会进入北京第二外语大学旅游管理学部研究生院深造。担任过日本旅游业协会国际部部长，中日恢复邦交正常化35周年时，作为中日政府旅游业务的交流窗口，一直与中国政府和其他同行保持着很好的合作关系，不论是机场的迎送，还是政府间的访问交流，无论什么样规模的业务都能够很好地完成。如果有机会来东京做客，请一定联系秋泽先生。</p>', '0', '1', '0', '0', '1', '0', '1490887575', '1', '0', '东京|8小时|明星', '代|', '东京');
INSERT INTO `mini_goods` VALUES ('72', '1', '8fbb4497-0656-5ff4-540f-fe8a5320bc6e', '旅行轻模式', '100', '0.10', '上百种特色好玩的旅游内容包随意搭配任意组合，专为自由行提供', '', '', '', '/uploads/picture/20170330/8846f525fe4d3cc4896fb2dc2f438a82.jpg', '', '', '', '', '0', '1', '0', '0', '1', '0', '1490888477', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('73', '1', 'e2f52bc4-55f5-c266-0878-323a419c5a84', '多年专注日本', '100', '0.10', '提供最优质的日本旅行服务，凭借丰富的经验打造日本定制旅行品牌。', '', '', '', '/uploads/picture/20170330/873ac5ae3971d1b3a2c1f83b92e19064.jpg', '', '', '', '', '0', '1', '0', '0', '1', '0', '1490888640', '1', '0', '', '', '');
INSERT INTO `mini_goods` VALUES ('74', '1', '6e848bbb-cd83-9358-aa54-e81de30c6177', '专业贴心服务', '100', '0.10', '您在旅行期间都会分配微信群，随时接受您的询问。解决各种突发问题。', '', '', '', '/uploads/picture/20170330/6c215555635893b16381df009f5ced83.jpg', '', '', '', '', '0', '1', '0', '0', '1', '0', '1490888745', '1', '0', '', '', '');

-- -----------------------------
-- Table structure for `mini_goods_cate`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_cate`;
CREATE TABLE `mini_goods_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL COMMENT '分类名',
  `slug` varchar(200) NOT NULL COMMENT '缩略名',
  `cover_path` varchar(200) NOT NULL COMMENT '分类封面图',
  `pid` int(11) NOT NULL DEFAULT '0',
  `page_num` int(11) NOT NULL,
  `lists_tpl` varchar(200) NOT NULL,
  `detail_tpl` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:启用，2：禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_goods_cate`
-- -----------------------------
INSERT INTO `mini_goods_cate` VALUES ('25', '轻定制', 'qdz', '', '0', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('26', '亲途达人/私导', 'qtdr', '', '0', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('27', '主题定制', 'ztdz', '', '0', '6', 'goods_ztdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('28', '全部', 'qdz_area_all', '', '30', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('29', '北海道', 'qdz_area_bhd', '', '30', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('30', '地区', 'qdz_area', '', '25', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('32', '特色', 'qdz_tese', '', '25', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('33', '全部', 'qdz_tese_all', '', '32', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('34', '地区', 'qtdr_area', '', '26', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('35', '全部', 'qtdr_area_all', '', '34', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('36', '特色', 'qtdr_tese', '', '26', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('37', '全部', 'qtdr_tese_all', '', '36', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('38', '北海道', 'qtdr_area_bhd', '', '34', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('39', '东北', 'qtdr_area_db', '', '34', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('40', '亲途达人', 'qtdr_tese_qtdr', '', '36', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('41', '明星私导', 'qtdr_tese_mxsd', '', '36', '8', 'goods_qtdr_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('42', '独家体验', 'qdz_tese_djty', '', '32', '6', 'goods_qdz_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('43', '分享旅行', 'fx', '', '0', '6', 'goods_list', 'goods_detail', '1');
INSERT INTO `mini_goods_cate` VALUES ('44', '', '', '', '0', '6', 'goods_list', 'goods_detail', '1');

-- -----------------------------
-- Table structure for `mini_goods_cate_relationships`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_cate_relationships`;
CREATE TABLE `mini_goods_cate_relationships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `cate_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=527 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_goods_cate_relationships`
-- -----------------------------
INSERT INTO `mini_goods_cate_relationships` VALUES ('295', '52', '27');
INSERT INTO `mini_goods_cate_relationships` VALUES ('296', '54', '27');
INSERT INTO `mini_goods_cate_relationships` VALUES ('297', '55', '27');
INSERT INTO `mini_goods_cate_relationships` VALUES ('298', '56', '27');
INSERT INTO `mini_goods_cate_relationships` VALUES ('300', '58', '27');
INSERT INTO `mini_goods_cate_relationships` VALUES ('304', '59', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('305', '59', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('306', '59', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('307', '59', '41');
INSERT INTO `mini_goods_cate_relationships` VALUES ('342', '57', '27');
INSERT INTO `mini_goods_cate_relationships` VALUES ('363', '61', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('364', '61', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('365', '61', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('366', '61', '32');
INSERT INTO `mini_goods_cate_relationships` VALUES ('390', '64', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('391', '64', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('392', '64', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('393', '64', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('394', '63', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('395', '63', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('396', '63', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('397', '63', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('398', '62', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('399', '62', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('400', '62', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('401', '62', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('402', '50', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('403', '50', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('404', '50', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('405', '50', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('410', '66', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('411', '66', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('412', '66', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('413', '66', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('414', '65', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('415', '65', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('416', '65', '29');
INSERT INTO `mini_goods_cate_relationships` VALUES ('417', '65', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('422', '49', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('423', '49', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('424', '49', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('425', '49', '42');
INSERT INTO `mini_goods_cate_relationships` VALUES ('430', '67', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('431', '67', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('432', '67', '33');
INSERT INTO `mini_goods_cate_relationships` VALUES ('433', '67', '42');
INSERT INTO `mini_goods_cate_relationships` VALUES ('437', '68', '25');
INSERT INTO `mini_goods_cate_relationships` VALUES ('438', '68', '28');
INSERT INTO `mini_goods_cate_relationships` VALUES ('439', '68', '42');
INSERT INTO `mini_goods_cate_relationships` VALUES ('477', '51', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('478', '51', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('479', '51', '38');
INSERT INTO `mini_goods_cate_relationships` VALUES ('480', '51', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('481', '51', '40');
INSERT INTO `mini_goods_cate_relationships` VALUES ('486', '69', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('487', '69', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('488', '69', '38');
INSERT INTO `mini_goods_cate_relationships` VALUES ('489', '69', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('490', '69', '40');
INSERT INTO `mini_goods_cate_relationships` VALUES ('496', '70', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('497', '70', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('498', '70', '38');
INSERT INTO `mini_goods_cate_relationships` VALUES ('499', '70', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('500', '70', '41');
INSERT INTO `mini_goods_cate_relationships` VALUES ('511', '71', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('512', '71', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('513', '71', '38');
INSERT INTO `mini_goods_cate_relationships` VALUES ('514', '71', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('515', '71', '41');
INSERT INTO `mini_goods_cate_relationships` VALUES ('517', '53', '43');
INSERT INTO `mini_goods_cate_relationships` VALUES ('519', '72', '43');
INSERT INTO `mini_goods_cate_relationships` VALUES ('520', '73', '43');
INSERT INTO `mini_goods_cate_relationships` VALUES ('521', '74', '43');
INSERT INTO `mini_goods_cate_relationships` VALUES ('522', '60', '26');
INSERT INTO `mini_goods_cate_relationships` VALUES ('523', '60', '35');
INSERT INTO `mini_goods_cate_relationships` VALUES ('524', '60', '36');
INSERT INTO `mini_goods_cate_relationships` VALUES ('525', '60', '37');
INSERT INTO `mini_goods_cate_relationships` VALUES ('526', '60', '40');

-- -----------------------------
-- Table structure for `mini_goods_collection`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_collection`;
CREATE TABLE `mini_goods_collection` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT NULL COMMENT '用户id',
  `goods_id` int(10) DEFAULT NULL COMMENT '商品id',
  `createtime` varchar(11) DEFAULT NULL COMMENT '收藏时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_goods_comment`
-- -----------------------------
DROP TABLE IF EXISTS `mini_goods_comment`;
CREATE TABLE `mini_goods_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增唯一ID',
  `uid` int(20) DEFAULT NULL,
  `goods_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应文章ID',
  `order_id` varchar(20) DEFAULT NULL COMMENT '订单号',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '评论时间',
  `content` text NOT NULL COMMENT '评论正文',
  `approved` varchar(20) NOT NULL DEFAULT '0' COMMENT '审核 0-待审核  1-已审核',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父评论ID',
  `score` int(2) DEFAULT NULL COMMENT '商品评分',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 -1-删除  1-正常',
  PRIMARY KEY (`id`),
  KEY `comment_post_ID` (`goods_id`),
  KEY `comment_approved_date_gmt` (`approved`),
  KEY `comment_parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_key_value`
-- -----------------------------
DROP TABLE IF EXISTS `mini_key_value`;
CREATE TABLE `mini_key_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `collection` varchar(128) NOT NULL COMMENT '命名集合键和值对',
  `uuid` varchar(128) NOT NULL DEFAULT 'default' COMMENT '系统唯一标识',
  `name` varchar(128) NOT NULL COMMENT '键名',
  `value` longtext NOT NULL COMMENT 'The value.',
  PRIMARY KEY (`id`,`collection`,`uuid`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_key_value`
-- -----------------------------
INSERT INTO `mini_key_value` VALUES ('1', 'config.base', 'default', 'web_allow_register', '1');
INSERT INTO `mini_key_value` VALUES ('2', 'config.base', 'default', 'web_site_close', '0');
INSERT INTO `mini_key_value` VALUES ('3', 'config.base', 'default', 'web_site_description', '亲途旅游网');
INSERT INTO `mini_key_value` VALUES ('4', 'config.base', 'default', 'web_site_icp', '冀ICP备XXXXXXX');
INSERT INTO `mini_key_value` VALUES ('5', 'config.base', 'default', 'web_site_keyword', '亲途旅游网');
INSERT INTO `mini_key_value` VALUES ('6', 'config.base', 'default', 'web_site_title', '亲途旅游网');
INSERT INTO `mini_key_value` VALUES ('7', 'config.base', 'default', 'web_allow_ticket', '0');
INSERT INTO `mini_key_value` VALUES ('8', 'indextheme', 'default', 'name', 'qintu');
INSERT INTO `mini_key_value` VALUES ('8', 'users', 'ad75820a-96c3-a1a8-20c6-195534dd75d3', 'is_root', '1');
INSERT INTO `mini_key_value` VALUES ('9', 'posts.form', '9db99141-65a4-2393-bfa8-d4d100e1a1f4', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('10', 'posts.form', '1d3fa553-6e07-eed6-f459-4694de378122', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('29', 'posts.form', '085b628d-d8ae-d04c-dfa0-61992ca70f29', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('30', 'posts.form', '3cf4069c-80d0-ac82-fcfe-e7e378569c12', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('31', 'posts.form', '7df6d672-48ef-b8ed-1d18-74c3770dcbc3', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('32', 'posts.form', '7faa2c91-b173-6bd2-4b69-c0234c7c1a57', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('33', 'posts.form', 'b64c7e04-b8a0-eeda-0314-35eabe258111', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('34', 'posts.form', '8bc618f8-c8a4-2219-fee2-2da0a71ca8ff', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('35', 'posts.form', '8cfc3471-3754-30cb-b030-a11dba360e0c', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('36', 'posts.form', '9bb4e644-482b-c2cd-68c7-9a1a2f290435', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('37', 'posts.form', '1c6e5535-86e8-6e0b-548b-02e631b85b20', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('38', 'posts.form', '879bda21-07f8-df3c-9270-7789515157ed', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('39', 'posts.form', '74610495-ab86-d787-fa50-8ba3987b680b', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('40', 'posts.form', '76ce6961-894e-8d13-59c4-49881ddf6748', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('41', 'posts.form', '94714551-683d-aa79-6fb4-60dd70201473', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('42', 'posts.form', '11646a6e-cd35-bcdd-4136-c5b392b63a6f', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('43', 'posts.form', 'd27eea5e-e553-d2d5-b05b-9574af56ce3f', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('44', 'posts.form', '60e38eeb-97a5-61ac-be60-425f9f8eb1c5', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('45', 'posts.form', 'f569d8f0-0510-8c55-2cbf-f29a4ffea591', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('46', 'posts.form', 'e4ec7532-1686-71f3-f57e-e19cc49a81bf', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('47', 'posts.form', 'fabe0485-4f82-643a-6a46-cd8defc7f6d4', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('48', 'posts.form', '88de9d39-21e8-d00f-c8ff-2b56791ea559', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('49', 'users', '9fe83c25-864e-7fe8-370d-d97799be1d7e', 'is_root', '1');
INSERT INTO `mini_key_value` VALUES ('50', 'posts.form', 'f4d643a2-8507-fd72-c5af-e12a7e77b13a', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('51', 'posts.form', '6571e5b9-cf41-5e25-0cb9-9e7d07e62173', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('52', 'posts.form', '442721ec-7a93-0baa-cd58-a469fae43c13', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('53', 'posts.form', '6f4c8587-03e6-9d31-4325-c97384457543', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('54', 'posts.form', '9d348e6e-db9d-0ec9-4a36-666787af9a74', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('55', 'posts.form', 'b30eeb11-1ca4-e771-562f-644b56c66a7e', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('56', 'posts.form', 'fdd989d9-d0f4-64f8-6981-5e3945d089c0', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('66', 'posts.form', 'd5f45d6b-f40c-b798-c9ef-7d690078a166', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('67', 'posts.form', '5df49b2a-c711-301d-8320-af500ceb40c6', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('68', 'posts.form', '896d0d4d-cc3b-f43b-2000-e9604769eea0', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('69', 'posts.form', 'd842871c-3840-f944-efb2-caefedcf926e', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('70', 'posts.form', '3d57ca49-c45e-2266-067c-67cb2bde8603', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('71', 'posts.form', 'a3fc44c5-5731-114c-d576-cebcb6767ff7', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('72', 'posts.form', '591f72fc-def5-dc1d-1471-8bcb50b7d60d', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('73', 'posts.form', '0e05d041-23de-e42b-c88f-d3eb6c4dc365', 'page_tpl', 'page');
INSERT INTO `mini_key_value` VALUES ('155', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'page_num', '20');
INSERT INTO `mini_key_value` VALUES ('156', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'lists_tpl', 'news_list');
INSERT INTO `mini_key_value` VALUES ('157', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'detail_tpl', 'news_detail');
INSERT INTO `mini_key_value` VALUES ('158', 'term.taxonomy', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'bind_form', 'article');
INSERT INTO `mini_key_value` VALUES ('166', 'posts.form', '70654547-9aec-c618-9753-e80dd876181a', 'page_tpl', 'page_srdz');
INSERT INTO `mini_key_value` VALUES ('167', 'posts.form', 'e522aff9-c7d0-9cd2-0f07-7e428c622e5b', 'page_tpl', 'page_srdz');
INSERT INTO `mini_key_value` VALUES ('168', 'posts.form', '94a5b422-2d0b-072a-bee5-2179a7793615', 'page_tpl', 'page_syjl');
INSERT INTO `mini_key_value` VALUES ('176', 'posts.form', '533dba5e-9f57-0755-5753-f1f5e1d3b6cd', 'page_tpl', 'page_about');
INSERT INTO `mini_key_value` VALUES ('177', 'term.taxonomy', '0901e3e0-e01e-19d2-9840-b37c09ceaf3b', 'page_num', '20');
INSERT INTO `mini_key_value` VALUES ('178', 'term.taxonomy', '0901e3e0-e01e-19d2-9840-b37c09ceaf3b', 'lists_tpl', 'news_list');
INSERT INTO `mini_key_value` VALUES ('179', 'term.taxonomy', '0901e3e0-e01e-19d2-9840-b37c09ceaf3b', 'detail_tpl', 'news_detail');
INSERT INTO `mini_key_value` VALUES ('180', 'term.taxonomy', '0901e3e0-e01e-19d2-9840-b37c09ceaf3b', 'bind_form', 'article');
INSERT INTO `mini_key_value` VALUES ('183', 'posts.form', '16b3ae37-b073-37a0-5d00-b31e8789a277', 'description', '');
INSERT INTO `mini_key_value` VALUES ('185', 'posts.form', 'eb3497f2-9a1e-96de-7253-fde21761504d', 'description', '');
INSERT INTO `mini_key_value` VALUES ('186', 'posts.form', '7b03685e-9066-073f-d109-0d66b8b78faf', 'description', '');
INSERT INTO `mini_key_value` VALUES ('187', 'posts.form', '482a47c1-60c9-8153-14aa-853f4ce2630b', 'description', '');
INSERT INTO `mini_key_value` VALUES ('188', 'posts.form', '6d3eea90-5f89-4f3e-9c74-657a8242f1ed', 'description', '');
INSERT INTO `mini_key_value` VALUES ('193', 'posts.form', '56f9a7a3-57f5-7a07-fb6f-866ad7ef9e8b', 'description', '');
INSERT INTO `mini_key_value` VALUES ('199', 'posts.form', '14664108-1e54-56cb-46cd-153f0f3916c7', 'description', '');
INSERT INTO `mini_key_value` VALUES ('201', 'posts.form', '32812f56-1972-7d72-92f2-33e680939959', 'description', '');
INSERT INTO `mini_key_value` VALUES ('204', 'posts.form', '9f9563a1-0e4c-daf5-43bb-880e54330bb6', 'description', '');
INSERT INTO `mini_key_value` VALUES ('209', 'posts.form', 'c79103ad-c098-c462-0bda-e0c1ceef5b59', 'description', '');
INSERT INTO `mini_key_value` VALUES ('210', 'posts.form', 'c88ee252-113e-636b-304c-fc86822b43dd', 'description', '');
INSERT INTO `mini_key_value` VALUES ('211', 'posts.form', '8a9aef9c-e7b2-4dc6-d2f2-f9722c53a46a', 'description', '');
INSERT INTO `mini_key_value` VALUES ('212', 'posts.form', 'ed42c448-d676-c057-b6f2-2aeab2dfc1c6', 'description', '');
INSERT INTO `mini_key_value` VALUES ('213', 'posts.form', 'c9afa567-4d27-b06e-392b-185e1e967573', 'description', '');
INSERT INTO `mini_key_value` VALUES ('214', 'posts.form', 'd747fe3e-bd6e-8e5b-3b8e-5ad877f2b97f', 'description', '');
INSERT INTO `mini_key_value` VALUES ('219', 'posts.form', '6b314ef5-23cc-77bb-275b-07a821988c5d', 'description', '已有567位朋友亲身体验了亲途的不一样。');

-- -----------------------------
-- Table structure for `mini_links`
-- -----------------------------
DROP TABLE IF EXISTS `mini_links`;
CREATE TABLE `mini_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增唯一ID',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接URL',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '链接标题',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '链接图片',
  `target` varchar(25) NOT NULL DEFAULT '' COMMENT '链接打开方式',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '链接描述',
  `visible` varchar(20) NOT NULL DEFAULT 'Y' COMMENT '是否可见（Y/N）',
  `owner` bigint(20) unsigned NOT NULL DEFAULT '1' COMMENT '添加者用户ID',
  `createtime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `link_visible` (`visible`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_links`
-- -----------------------------
INSERT INTO `mini_links` VALUES ('1', 'http://www.baidu.com', '百度', '/uploads/picture/20161209/707e87d63b2b3b561df33d8a510b19cf.png', '_blank', '百度', 'Y', '1', '1474877272');

-- -----------------------------
-- Table structure for `mini_menu`
-- -----------------------------
DROP TABLE IF EXISTS `mini_menu`;
CREATE TABLE `mini_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_menu`
-- -----------------------------
INSERT INTO `mini_menu` VALUES ('1', '文章', 'fa fa-fw fa-files-o', '0', '0', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('2', '订单', 'fa fa-fw fa-exchange', '0', '3', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('3', '会员', 'fa fa-fw fa-users', '0', '4', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('4', '设置', 'fa fa-gears', '0', '5', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('5', '个人', 'fa fa-fw fa-user', '0', '6', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('31', '写文章', 'fa fa-fw fa-edit', '1', '1', 'post/add', '0', '0');
INSERT INTO `mini_menu` VALUES ('32', '所有文章', 'fa fa-fw fa-file', '1', '0', 'post/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('37', '分类目录', 'fa fa-fw fa-cubes', '1', '2', 'taxonomy/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('38', '订单列表', 'fa fa-money', '2', '0', 'order/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('39', '会员列表', 'fa fa-fw fa-user', '3', '0', 'member/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('40', '添加会员', 'fa fa-fw fa-user-plus', '3', '1', 'member/add', '0', '0');
INSERT INTO `mini_menu` VALUES ('41', '基本设置', 'fa  fa-wrench', '4', '0', 'config/edit', '0', '0');
INSERT INTO `mini_menu` VALUES ('42', '菜单设置', 'fa  fa-navicon ', '4', '1', 'menu/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('43', '个人资料', 'fa fa-user-times', '5', '0', 'user/edit', '0', '0');
INSERT INTO `mini_menu` VALUES ('44', '修改密码', 'fa fa-fw fa-key', '5', '1', 'user/password', '0', '0');
INSERT INTO `mini_menu` VALUES ('48', '插件', 'fa fa-puzzle-piece', '0', '7', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('49', '广告管理', 'fa  fa-picture-o', '48', '1', 'banner/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('50', '导航设置', 'fa  fa-cog', '4', '2', 'navigation/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('51', '页面', 'fa fa-newspaper-o', '0', '1', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('52', '所有页面', 'fa fa-fw fa-file', '51', '0', 'page/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('53', '新增页面', 'fa fa-edit (alias)', '51', '1', 'page/add', '0', '0');
INSERT INTO `mini_menu` VALUES ('54', '权限设置', 'fa fa-plug', '4', '0', 'authmanager/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('55', '广告位置', 'fa fa-picture-o', '48', '0', 'banner_position/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('56', '链接管理', 'fa fa-link', '48', '3', 'links/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('59', '登录', '', '0', '0', 'index/index', '1', '0');
INSERT INTO `mini_menu` VALUES ('58', '评论管理', 'fa fa-comment-o', '48', '0', 'comment/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('60', '删除分类', '', '37', '0', 'taxonomyt/setStatus', '1', '0');
INSERT INTO `mini_menu` VALUES ('61', '添加分类目录', '', '37', '0', 'taxonomy/edit', '1', '0');
INSERT INTO `mini_menu` VALUES ('64', '主题设置', 'fa fa-sliders', '4', '5', 'theme/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('65', '微信设置', 'fa fa-plug', '4', '0', 'wx/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('67', '接口设置', 'fa fa-support', '4', '7', 'apiconfig/edit', '0', '0');
INSERT INTO `mini_menu` VALUES ('68', '数据库', 'fa fa-cog', '0', '8', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('69', '数据库备份', 'fa fa-cog', '68', '0', 'Database/index?type=export', '0', '0');
INSERT INTO `mini_menu` VALUES ('70', '数据库还原', 'fa fa-cog', '68', '0', 'Database/index?type=import', '0', '0');
INSERT INTO `mini_menu` VALUES ('71', '商品', 'fa fa-shopping-cart', '0', '2', '#', '0', '0');
INSERT INTO `mini_menu` VALUES ('72', '所有商品', ' fa fa-shopping-cart', '71', '0', 'goods/index', '0', '0');
INSERT INTO `mini_menu` VALUES ('73', '添加商品', 'fa  fa-plus-square', '71', '1', 'goods/goodsadd', '0', '0');
INSERT INTO `mini_menu` VALUES ('74', '商品分类', 'fa fa-list', '71', '2', 'goods/category', '0', '0');
INSERT INTO `mini_menu` VALUES ('75', '私人需求单', 'fa fa-money', '2', '0', 'order/person', '0', '0');
INSERT INTO `mini_menu` VALUES ('76', '商业需求单', 'fa fa-money', '2', '0', 'order/business', '0', '0');

-- -----------------------------
-- Table structure for `mini_navigation`
-- -----------------------------
DROP TABLE IF EXISTS `mini_navigation`;
CREATE TABLE `mini_navigation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_navigation`
-- -----------------------------
INSERT INTO `mini_navigation` VALUES ('1', '轻定制', 'fa fa-fw fa-files-o', '0', '0', 'goods/lists?category=qdz_area_all|qdz_tese_all', '0');
INSERT INTO `mini_navigation` VALUES ('2', '达人私导', 'fa fa-fw fa-exchange', '0', '1', 'goods/lists?category=qtdr_area_all|qtdr_tese_all', '0');
INSERT INTO `mini_navigation` VALUES ('3', '私人定制', 'fa fa-fw fa-users', '0', '2', 'article/page?name=srdz', '0');
INSERT INTO `mini_navigation` VALUES ('4', '主题路线', 'fa fa-gears', '0', '3', 'goods/lists?category=ztdz', '0');
INSERT INTO `mini_navigation` VALUES ('5', '商业交流', 'fa fa-fw fa-edit', '0', '5', 'article/page?name=syjl', '0');
INSERT INTO `mini_navigation` VALUES ('10', '关于我们', 'fa fa-fw fa-users', '0', '6', 'article/page?name=about', '0');

-- -----------------------------
-- Table structure for `mini_orders`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders`;
CREATE TABLE `mini_orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `order_no` varchar(20) NOT NULL COMMENT '订单号',
  `print_no` varchar(30) DEFAULT NULL COMMENT '小票打印机单号',
  `express_type` varchar(100) DEFAULT NULL COMMENT '快递方式',
  `express_no` varchar(100) DEFAULT NULL COMMENT '快递编号',
  `pay_type` varchar(10) NOT NULL COMMENT '支付方式',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '总金额',
  `createtime` int(11) NOT NULL,
  `is_pay` int(11) NOT NULL DEFAULT '0',
  `status` varchar(10) NOT NULL COMMENT '支付状态',
  `memo` varchar(255) DEFAULT NULL COMMENT '订单备注',
  `consignee_name` varchar(100) DEFAULT NULL COMMENT '收货人',
  `address` text COMMENT '收货地址',
  `mobile` varchar(11) DEFAULT NULL COMMENT '收货人电话',
  PRIMARY KEY (`id`,`uuid`,`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders`
-- -----------------------------
INSERT INTO `mini_orders` VALUES ('73', '442ba8af-7fd7-84f6-1a30-6140f85703bd', '1', '2017032353485397', '', '', '', 'wxpay', '700.00', '1490255221', '0', 'nopaid', '', '哈哈', '北京东城区了开发的发放', '13810773215');
INSERT INTO `mini_orders` VALUES ('74', 'ae637617-0e7f-6986-f645-68edfe99cd9f', '1', '2017032456564853', '', '', '', 'wxpay', '760.00', '1490332760', '0', 'nopaid', '', '哈哈', '北京东城区了开发的发放', '13810773215');
INSERT INTO `mini_orders` VALUES ('79', 'aaa6704e-636e-0dba-f3f1-06c58d9da20e', '1', '2017032498519799', '', '', '', '', '0.00', '1490341083', '1', '', '', '', '', '');
INSERT INTO `mini_orders` VALUES ('80', 'ca6419eb-1dbd-81f5-bb75-4dcd78b53f82', '1', '2017032410155525', '', '', '', '', '0.00', '1490341454', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('81', '1f93c9b2-1d89-efc9-6894-0f15cca621bd', '1', '2017032457515455', '', '', '', '', '0.00', '1490341545', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('82', '065d1da4-f4c8-0d5f-03fc-2f7694689cea', '1', '2017032448971001', '', '', '', '', '0.00', '1490342192', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('83', 'abb562af-0a28-3d8b-839e-a216377eeb85', '1', '2017032410152519', '', '', '', '', '0.00', '1490343230', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('84', 'd866706e-e4d7-3ef2-c865-b26955eff6f9', '1', '2017032451529949', '', '', '', '', '0.00', '1490343235', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('85', '927cd2de-0f6a-c79f-c4d7-0479c614737f', '1', '2017032455545048', '', '', '', '', '0.00', '1490343911', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('86', '0ed8024c-debd-8779-8f92-6bac59994a8c', '1', '2017032498971025', '', '', '', '', '0.00', '1490343915', '1', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('87', 'b69613f5-e48c-fac5-6a15-9d20ee765bff', '1', '2017032410250100', '', '', '', '', '0.00', '1490344127', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('88', 'a9ec269c-631f-403b-0b6e-6b6e368e94d8', '1', '2017032749495698', '', '', '', '', '0.00', '1490590129', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('89', 'd08e7097-f06c-c3a7-4092-e9841f0d17e0', '1', '2017032757995251', '', '', '', '', '0.00', '1490590137', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('90', '05f4ce26-483d-f1b2-504c-456c63a1646c', '1', '2017032710199555', '', '', '', '', '0.00', '1490590174', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('91', '35dc6982-5bdb-0f17-c1e8-23a96a7521a7', '1', '2017032755545051', '', '', '', '', '0.00', '1490590183', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('92', '6640c8d9-5740-a8d0-5d20-8411518eaed5', '1', '2017032748995710', '', '', '', '', '0.00', '1490590208', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('93', 'ae79a01e-db4d-0cd0-5b31-0c01dc6dae20', '1', '2017032752565148', '', '', '', '', '0.00', '1490590244', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('94', '4716317c-16c1-8a81-c898-ff09321941c6', '1', '2017032749539755', '', '', '', '', '0.00', '1490590257', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('95', '13628904-129d-2554-eeb3-cff4a5ea9571', '1', '2017032798511001', '', '', '', '', '0.00', '1490590411', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('96', '4b10ac91-24c4-934b-92ed-9f6b211f7a49', '1', '2017032751515656', '', '', '', '', '0.00', '1490590467', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('97', '47b3a405-df5a-9edd-48c0-f6bf72e932ee', '1', '2017032856971025', '', '', '', '', '0.00', '1490686360', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('98', '121bc992-3daa-9523-1015-37fba6782091', '1', '2017032810256541', '', '', '', '', '0.00', '1490686479', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('99', '1cb4774a-bb58-f0b3-4365-fba48642502c', '1', '2017033051545557', '', '', '', '', '0.00', '1490875395', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('100', 'eb8e6839-4dcd-92ce-13c4-40b7ce1fbb32', '1', '2017033057511025', '', '', '', '', '0.00', '1490875401', '0', '', '', '', '', ' ');
INSERT INTO `mini_orders` VALUES ('101', 'd1d46951-371d-4153-103e-cb2032b12028', '35', '2017033098485256', '', '', '', '', '0.00', '1490876619', '0', '', '', '', '', '13621093997');
INSERT INTO `mini_orders` VALUES ('102', '1ffea46c-bcc6-0059-5e4d-533ffdda3ef9', '35', '2017033010298101', '', '', '', '', '0.00', '1490885023', '0', '', '', '', '', '13621093997');
INSERT INTO `mini_orders` VALUES ('103', 'f812c86e-bf42-8ade-43de-83944425b9ec', '36', '2017033054554810', '', '', '', '', '0.00', '1490885094', '0', '', '', '', '', '13621093998');

-- -----------------------------
-- Table structure for `mini_orders_address`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_address`;
CREATE TABLE `mini_orders_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `consignee_name` varchar(100) NOT NULL COMMENT '收货人',
  `province` varchar(100) NOT NULL COMMENT '省',
  `city` varchar(100) NOT NULL COMMENT '市',
  `county` varchar(100) NOT NULL COMMENT '县/区',
  `address` text NOT NULL COMMENT '详细地址',
  `mobile` varchar(11) NOT NULL COMMENT '联系电话',
  `status` int(10) NOT NULL DEFAULT '1' COMMENT '1-正常 -1-已删除',
  `default` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为默认收货地址1-是 0-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders_address`
-- -----------------------------
INSERT INTO `mini_orders_address` VALUES ('14', '1', '哈哈', '北京', '东城区', '', '了开发的发放', '13810773215', '1', '1');

-- -----------------------------
-- Table structure for `mini_orders_goods`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_goods`;
CREATE TABLE `mini_orders_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(11) NOT NULL COMMENT '订单号',
  `goods_id` int(11) NOT NULL COMMENT '商品id',
  `name` varchar(255) NOT NULL,
  `num` int(10) NOT NULL COMMENT '购买数量',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `description` text NOT NULL,
  `standard` varchar(255) NOT NULL,
  `cover_path` varchar(255) NOT NULL,
  `is_comment` varchar(10) NOT NULL DEFAULT '-1' COMMENT '商品是否评论 -1-否  1-是',
  `departure_time` int(11) NOT NULL,
  `man_num` int(10) NOT NULL,
  `child_num` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_orders_goods`
-- -----------------------------
INSERT INTO `mini_orders_goods` VALUES ('74', '73', '42', '红枣夹核桃', '28', '25.00', '红枣夹核桃', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '-1', '0', '0', '0');
INSERT INTO `mini_orders_goods` VALUES ('75', '74', '44', '核桃仁', '1', '35.00', '核桃仁', '100克X10袋', '/uploads/picture/20161223/9da72a3997817954407982362b3ac40a.jpg', '-1', '0', '0', '0');
INSERT INTO `mini_orders_goods` VALUES ('76', '74', '42', '红枣夹核桃', '29', '25.00', '红枣夹核桃', '250克X3袋', '/uploads/picture/20161223/52f5e882a665079b8795b3d2ab367431.jpg', '-1', '0', '0', '0');
INSERT INTO `mini_orders_goods` VALUES ('79', '79', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('80', '80', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('81', '81', '0', '', '0', '0.00', '', '', '', '-1', '2017', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('82', '82', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('83', '83', '0', '', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('84', '84', '0', '', '0', '0.00', '', '', '', '-1', '2147483647', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('85', '85', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('86', '86', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1488412800', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('87', '87', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1488585600', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('88', '88', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('89', '89', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('90', '90', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('91', '91', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('92', '92', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('93', '93', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('94', '94', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '0', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('95', '95', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1488931200', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('96', '96', '47', '陕西冬枣', '0', '0.00', '', '', '', '-1', '1490227200', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('97', '99', '51', '亲途达人1', '0', '0.00', '', '', '', '-1', '1488844800', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('98', '100', '51', '亲途达人1', '0', '0.00', '', '', '', '-1', '1488844800', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('99', '101', '49', '轻定制产品1', '0', '0.00', '', '', '', '-1', '1492128000', '2', '0');
INSERT INTO `mini_orders_goods` VALUES ('100', '102', '62', '特色景点 | 函馆山', '0', '0.00', '', '', '', '-1', '1490832000', '1', '0');
INSERT INTO `mini_orders_goods` VALUES ('101', '103', '50', '特色景点 | 旭山动物园', '0', '0.00', '', '', '', '-1', '1494460800', '1', '0');

-- -----------------------------
-- Table structure for `mini_orders_status`
-- -----------------------------
DROP TABLE IF EXISTS `mini_orders_status`;
CREATE TABLE `mini_orders_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) NOT NULL COMMENT '订单号',
  `approve_uid` int(50) DEFAULT NULL COMMENT '审核人',
  `trade_no` varchar(50) DEFAULT NULL COMMENT '支付接口流水号',
  `trade_status` varchar(50) DEFAULT NULL COMMENT '支付接口状态',
  `status` varchar(30) NOT NULL COMMENT 'nopaid-未支付 paid-已支付,待发货  shipped-已发货  completed-收货已完成',
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_person_need`
-- -----------------------------
DROP TABLE IF EXISTS `mini_person_need`;
CREATE TABLE `mini_person_need` (
  `name` char(128) NOT NULL COMMENT '姓名',
  `mobile` varchar(128) NOT NULL COMMENT '手机号',
  `email` char(128) NOT NULL COMMENT '邮箱',
  `reached` char(128) DEFAULT NULL COMMENT '目的地',
  `out_date` char(128) DEFAULT NULL COMMENT '出行日期',
  `out_days` char(128) DEFAULT NULL COMMENT '出行天数',
  `man` int(11) DEFAULT NULL COMMENT '成人人数',
  `children` int(11) DEFAULT NULL COMMENT '儿童人数',
  `cost` char(128) DEFAULT NULL COMMENT '预计花费',
  `description` text COMMENT '备注',
  `createtime` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_person_need`
-- -----------------------------
INSERT INTO `mini_person_need` VALUES ('111111111111', '2147483647', '11@qq.com', '', '', '', '0', '0', '￥10000-￥30000', '', '0');
INSERT INTO `mini_person_need` VALUES ('11111111', '17744484319', '11@qq.com', '', '', '', '0', '0', '', '', '1490695473');
INSERT INTO `mini_person_need` VALUES ('张辉', '13621093922', '329112817@qq.com', '', '', '', '0', '0', '', '', '1490864183');

-- -----------------------------
-- Table structure for `mini_posts`
-- -----------------------------
DROP TABLE IF EXISTS `mini_posts`;
CREATE TABLE `mini_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增唯一ID',
  `uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应作者ID',
  `uuid` varchar(128) NOT NULL,
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `content` longtext NOT NULL COMMENT '正文',
  `title` text NOT NULL COMMENT '标题',
  `description` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish' COMMENT '文章状态（publish/draft/inherit等）',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open' COMMENT '评论状态（open/closed）',
  `password` varchar(20) NOT NULL DEFAULT '' COMMENT '文章密码',
  `name` varchar(200) NOT NULL DEFAULT '' COMMENT '文章缩略名',
  `updatetime` int(11) NOT NULL DEFAULT '0' COMMENT '修改时间',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '父文章，主要用于PAGE',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `type` varchar(20) NOT NULL DEFAULT 'post' COMMENT '文章类型（post/page等）',
  `comment` bigint(20) NOT NULL DEFAULT '0' COMMENT '评论总数',
  `view` int(11) NOT NULL DEFAULT '0' COMMENT '文章浏览量',
  PRIMARY KEY (`id`),
  KEY `post_name` (`name`(191)),
  KEY `type_status_date` (`type`,`status`,`createtime`,`id`),
  KEY `post_parent` (`pid`),
  KEY `post_author` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_posts`
-- -----------------------------
INSERT INTO `mini_posts` VALUES ('69', '1', '533dba5e-9f57-0755-5753-f1f5e1d3b6cd', '1490840098', '<p>关于我们</p>', '关于我们', '', 'publish', 'open', '', 'about', '1490840098', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('56', '1', '32812f56-1972-7d72-92f2-33e680939959', '1489980237', '<p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">1．面对众多诱人景色，您是否曾苦恼不知如何衔接？怎么到达？重点转哪里？无法取舍？专业日本当地导游为您设计行程，高效合理，告诉您怎么去，呆多久，看什么，下一站往哪里。让您省去诸多想象与现实的落差问题；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">2．何谓轻定制？您可以参考选取我们的景点和体验内容，也可单纯给出希望前往的目的地。一般人很难面面俱到规划好内容衔接，导致错过很多精彩瞬间。我们的专业人员在线下为您精确规划，指点迷津。并为您预订和沟通诸多身处中国无法预约或参与的当地精彩内容，为此我们仅收取固定的行程设计与代办费用；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">3．每一个景点我们都可以为您提供包车，公众交通工具，当地出发的本地大巴单项游团等到达方式，并完美地与下一个行程衔接，除去轻定制里的景点与体验内容，还有更多周边内容配套，您可以提出需求；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">4．我们还为您代订在携程或Hotel.com上无法订到或者价格偏高的酒店，欢迎与其对比价格；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">5．您如果偏向自由行，日本国内景点之间的移动以及体验均有我们在日本当地线下为您事先购买预定，并代替您与组织方沟通；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">6．您如果想要舒适行，各行各业的日本精英，精通中文，为您提供单个景点/体验到全程的陪同解说服务，让您真正不枉此行；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">7．日本文化延续不断，期间未有任何打断，所以各地传承上千年的祭祀，庙会，各种传统活动络绎不绝，亲途根据您的出行时期和地点，安排当地私导带领您融入到各种地方文化中，让您恍若隔世；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">8．无论哪种方式，我们在旅行期间都会为您分配微信群，随时随地接受您的询问，也随时为您解决各种突发问题如晚点后的重新规划路程问题；</span></p><p style="line-height: 1.75em;"><span style="color: rgb(0, 0, 0);">9．亲途的所有私导均拥有中文观光通译资格以及有偿导游资质，绝非普通人兼职这类灰色地带人员可比，在意外保险，突发情况对应方面经验丰富。</span></p><p><br/></p>', '选择亲途的理由', '', 'publish', 'open', '', 'why-choose', '1490864953', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('57', '1', '6b314ef5-23cc-77bb-275b-07a821988c5d', '1489982273', '<p><img src="/uploads/editor/image/20170331/1490918666822401.jpg" title="1490918666822401.jpg" alt="l1.jpg"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img src="/uploads/editor/image/20170331/1490918669801198.jpg" title="1490918669801198.jpg" alt="l2.jpg"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<img src="http://www.kintou.net/uploads/editor/image/20170331/1490918672200954.jpg" title="1490918672200954.jpg" alt="l3.jpg"/>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img src="http://www.kintou.net/uploads/editor/image/20170331/1490918674558786.jpg" title="1490918674558786.jpg" alt="l4.jpg"/></p><p>提交心愿单 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;制定轻行程 &nbsp; &nbsp; &nbsp;预约付款 &nbsp; &nbsp; &nbsp;&nbsp;开心出行</p><p>按照您的出行计划选择旅游包，添 &nbsp;&nbsp;</p><p>加至心愿单并提交，我们的客服会</p><p>在 2 小时内与您取得联系。</p><p><br/></p>', '轻定制服务流程', '', 'publish', 'open', '', '上百个特色旅游包任意搭配随意组合，只需提交心愿，剩下的一切交给亲途', '1490918974', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('71', '1', '9f9563a1-0e4c-daf5-43bb-880e54330bb6', '1490846546', '<p><strong>免责声明</strong></p><p>亲途旅行提醒您：在使用我们各项服务前，请您务必仔细阅读并透彻理解本声明。您可以选择不使用亲途旅行网服务，但如果您使用亲途旅行网服务的，您的使用行为将被视为对本声明全部内容的认可。</p><p><strong>服务说明</strong></p><p>亲途旅行网所提供的服务仅依其当前所呈现的状况提供，服务可能会受到各个环节不稳定因素的影响。您明确同意使用亲途旅行网服务所存在的风险将完全由您自己承担，亲途旅行网对此不承担任何责任。</p><p>亲途旅行网对本网站提供的服务不作任何明示或暗示的保证，包括但不限于服务的适用性、没有错误或疏漏、持续性、准确性、可靠性、适用于某一特定用途。同时，亲途旅行网也不对服务所涉及的技术及信息的有效性、准确性、正确性、可靠性、质量、稳定、完整和及时性作出任何承诺和保证。</p><p><strong>内容说明</strong></p><p>亲途旅行网平台转载作品（包括图片、文章内容）出于传递更多信息之目的，并不意味亲途旅行网赞同其观点或证实其内容的真实性。亲途旅行网尊重合法版权，反对侵权盗版。若本网有部分文字、摄影作品等侵害了您的权益，在此深表歉意，请您立即将侵权链接及侵权信息邮件至我们的版权投诉邮箱：825306059@qq.com，我们会尽快与您联系并解决。</p><p><strong>其它</strong></p><p>亲途旅行网不对因下述任一情况而导致您的任何损害承担任何直接、间接、附带、特别、衍生性或惩罚性赔偿，包括但不限于利润、商誉、使用、数据、资料等方面的损失或其它无形损失的损害赔偿 (无论本网站是否已被告知该等损害赔偿的可能性) ：</p><p>1、您对本网站及或对本网站所提供之服务的误解；</p><p>2、任何非因本网站的原因而引起的与本网站所提供之服务有关的其它损失。</p><p>3、任何由于计算机2000年问题、黑客政击、计算机病毒侵入或发作、因政府管制而造成的暂时性关闭等影响网络正常经营之不可抗力而造成的个人资料泄露、丢失、被盗用或被窜改等。</p><p>4、由于您将用户密码告知他人或与他人共享注册帐户，由此导致的任何个人资料泄露。</p><p>本声明适用中华人民共和国法律。如其中任何条款与中华人民共和国法律相抵触，则这些条款将完全按法律规定重新解释，而其它条款依旧具有法律效力。对免责声明的解释、修改及更新权均属于本网站所有。</p><p><br/></p>', '免责声明', '', 'publish', 'open', '', 'mzsm', '1490874577', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('70', '1', '8a9aef9c-e7b2-4dc6-d2f2-f9722c53a46a', '1490845222', '<p>亲途旅行成立于2016年，是中国最深度的日本定制旅游平台，总部位于日本东京新宿区，中国总公司设立在北京。</p><p>目前在中国集体旅游、抢购爆购已经逐渐成为过去，自由行如今方兴未艾。越来越多的中国年轻人希望打破自己固定的社交圈，带上几本导游册，买上一张机票就踏上了旅途，去体验不同国家不社会群体的别样生活。这样的方式虽然自由且花费较少，但是舒适度会受到影响，行程安排也可能不科学，个人需要应付较为复杂且多变的状况。如何帮助中国年轻人更好更深地融入当地文化，体验更极致的生活方式，结交更有趣的良师益友，这是我们打造这个社交平台的初衷。&nbsp;</p><p>亲途旅行与日本最大的中文信息门户RecordChina为兄弟公司和日本中文导游协会为战略合作伙伴。依托RecordChina门户基础，将分散在日本各地区和各行业的中文导游或者愿意接纳中国游客的个人以及团体集中起来，共同开发出独具特色的旅游和体验项目，然后通过亲途旅行平台发布给中国游客，供其选择，也作为面向中国业者的内容供应商提供定制业务。</p><p><br/></p>', '关于我们', '', 'publish', 'open', '', 'about_me', '1490875198', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('60', '1', '56f9a7a3-57f5-7a07-fb6f-866ad7ef9e8b', '1490601140', '<p>1111<br/></p>', '达人体验服务流程', '', 'publish', 'open', '', 'server-proces-qtdr', '1490863058', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('61', '1', 'e522aff9-c7d0-9cd2-0f07-7e428c622e5b', '1490686244', '<p>11111</p>', '私人定制', '', 'publish', 'open', '', 'srdz', '1490686344', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('62', '1', '94a5b422-2d0b-072a-bee5-2179a7793615', '1490691894', '<p>saaaa</p>', '商业交流', '', 'publish', 'open', '', 'syjl', '1490691894', '0', '0', 'page', '0', '0');
INSERT INTO `mini_posts` VALUES ('63', '1', '14664108-1e54-56cb-46cd-153f0f3916c7', '1490779682', '<p style="line-height: 1.75em;"><span style="line-height: 1.75em;">我们提供的该服务产品主要为考察，基本流程为客户提出需求，我方就日程，对象，目的，规模进行综合衡量后给出初步方案以及报价，在获得客户认可后联系并安排日方对口企业进行参观，交流等活动。在此过程中，我方还提供商务游说服务，并有配套商务咨询业务，以达成客户进一步的派员学习，业务合作等目标。</span><br/></p><p><br/></p>', '商业交流领域', '', 'publish', 'open', '', 'post-syjl', '1490863325', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('64', '1', '482a47c1-60c9-8153-14aa-853f4ce2630b', '1490780313', '<p>索尼，松下，JVC，丰田，三菱重工，欧姆龙等各行业制造商</p><p><br/></p>', '工业制造', '', 'publish', 'open', '', 'post-gyzz', '1490862738', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('65', '1', '6d3eea90-5f89-4f3e-9c74-657a8242f1ed', '1490780338', '<p>日本物流协会，日本零售业协会，松本清药妆，日立物流，鸿池医疗，圣隶老年公寓等各行业领先的服务商</p><p><br/></p>', '社会服务', '', 'publish', 'open', '', 'post-shfw', '1490862752', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('66', '1', '7b03685e-9066-073f-d109-0d66b8b78faf', '1490780361', '<p>史克威尔艾尼克斯等游戏厂商，日本电影协会等动漫制作团体</p><p><br/></p>', '动漫文化', '', 'publish', 'open', '', 'post-dmwh', '1490862721', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('67', '1', 'eb3497f2-9a1e-96de-7253-fde21761504d', '1490780380', '<p>日本设计师联合会，多名世界知名时装设计，平面设计大师</p><p><br/></p>', '时尚流行', '', 'publish', 'open', '', 'post-shlx', '1490862704', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('68', '1', '16b3ae37-b073-37a0-5d00-b31e8789a277', '1490780423', '<p>CyberDyne等世界领先的机器人以及人工智能企业</p><p><br/></p>', '机器人制造', '', 'publish', 'open', '', 'post-jqrzz', '1490862629', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('72', '1', 'ed42c448-d676-c057-b6f2-2aeab2dfc1c6', '1490874493', '<p>在您将个人信息提供给www.kintou.net（亲途旅行网）之前，请您仔细阅读本隐私条款以了解我们的隐私条款和保密措施。在访问本网站www.kintou.net的同时，您确认了解并接受在此介绍的保密措施。</p><p><strong>1、信息安全</strong></p><p>本网站将对您所提供的资料进行严格的管理及保护，本网站将使用相应的技术，防止您的个人资料丢失、被盗用或遭窜改。</p><p>本网站得在必要时委托专业技术人员代为对该类资料进行电脑处理，以符合专业分工时代的需求。如本网站将电脑处理之通知送达予您，而您未在通知规定的时间内主动明示反对，本网站将推定您已同意。惟在其后您仍然有权如下述第4.4条之规定，请求停止电脑处理。</p><p><strong>2、个人资料</strong></p><p>当您在亲途旅行网站进行用户注册登记、定制业务等活动时，在您的同意及确认下，本网站将通过注册表格、订单等形式要求您提供一些个人资料。这些个人资料包括：</p><p>1）个人识别资料：如姓名、性别、年龄、出生日期、身份证号码、电话、通信地址、住址、电子邮件地址等情况；</p><p>2）个人背景：职业、教育程度、收入状况、婚姻、家庭状况。 请了解，在未经您同意及确认之前，本网站不会将您为参加本网站之特定活动所提供的资料利用于其它目的。</p><p>当政府机关依照法定程序要求本网站披露个人资料时，本网站将根据执法单位之要求或为公共安全之目的提供个人资料。在此情况下之任何披露，本网站均得免责。</p><p><strong>3、使用者非个人化信息</strong></p><p>我们将通过您的IP地址来收集非个人化的信息，例如您的浏览器性质、操作系统种类、给您提供接入服务的ISP的域名等，以优化在您计算机屏幕上显示的页面。通过收集上述信息，我们亦进行客流量统计，从而改进网站的管理和服务。</p><p><strong>4、用户权利</strong></p><p>您对于自己的个人资料享有以下权利：</p><p>1）随时查询及请求阅览；</p><p>2）随时请求补充或更正；</p><p>3）随时请求删除；</p><p>4）请求停止电脑处理及利用。</p><p><strong>5、未成年人保护</strong></p><p>亲途旅行非常重视对未成年人个人信息的保护。若您是18周岁以下的未成年人，在使用亲途旅行的服务前，应事先取得您家长或法定监护人的书面同意。</p><p><strong>6、第三方合作</strong></p><p>亲途旅行网可能会与第三方合作向用户提供相关的网络服务，在此情况下，如该第三方同意承担与亲途旅行网同等的保护用户隐私的责任，则亲途旅行网可将用户的注册资料等提供给该第三方。</p><p>我们可能与合作伙伴一起为您提供产品或者服务。当有第三方参与提供您所希望获得的产品或服务时，您会发现这一点，因为他们的名字将会与我们的名字一同显示。如果您愿意(您有权自主决定是否愿意)接受该服务，我们将与相关合作伙伴共享您的信息，包括个人信息。请您注意，我们并不控制第三方合作伙伴的隐私政策及保密措施。</p><p><strong>7、第三方链接</strong></p><p>亲途旅行网提供第三方链接只作为对用户的一种便利。为了您的方便，亲途旅行网向您提供此链接，该链接会使您离开仙贝旅行网站。由于所链接的网站不在亲途旅行网的控制范围内，所以，对于任何所链接的网站上的内容或某一链接的网站所含的任何链接或对该等网站的任何变动或更新，亲途旅行网不负责任。亲途旅行网对从所链接的网站收到的网络传送(Webcasting)或任何其它形式的传输不承担任何责任。</p><p><strong>8、cookies</strong></p><p>Cookies是指一种技术，当使用者访问设有Cookies装置的本网站时，亲途旅行网站之服务器会自动发送Cookies至阁下浏览器内，并储存到您的电脑硬盘内，此Cookies便负责记录日后您到访本网站的种种活动、个人资料、浏览习惯、消费习惯甚至信用记录。</p><p>运用Cookies技术，本网站能够为您提供更加周到的个性化服务。本网站将会运用Cookies追访您的购物喜好，从而向您提供感兴趣的信息资料或储存密码，以便您造访本网站时不必每次重复输入密码。</p><p><strong>9、结束服务</strong></p><p>用户或亲途旅行网可随时根据实际情况中止网站服务。亲途旅行网不需对任何个人或第三方负责而随时中断服务。用户若反对任何服务条款的建议或对后来的条款修改有异议，或对亲途旅行用户服务不满，用户只有以下的追索权：&nbsp;</p><p>1）不再使用亲途旅行网服务；</p><p>2）结束用户亲途旅行网服务的资格；</p><p>3）通告亲途旅行网停止该用户的服务。 结束用户服务后，用户使用亲途旅行网服务的权利马上中止。从那时起，亲途旅行网不再对用户承担任何义务。</p><p><strong>10、隐私条款的修改</strong></p><p>亲途旅行网会在必要时修改隐私条款，亲途旅行网隐私条款一旦发生变动，公司将会在用户进入下一步使用前的页面提示修改内容。您有权接受或拒绝，如果用户要继续使用亲途旅行网服务需要两方面的确认：&nbsp;</p><p>1）先确认亲途旅行网服务条款及其变动。&nbsp;</p><p>2）同意接受所有的服务条款限制。</p><p><br/></p>', '隐私条款', '', 'publish', 'open', '', '隐私条款', '1490875219', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('73', '1', 'c79103ad-c098-c462-0bda-e0c1ceef5b59', '1490874797', '<p><strong>申请退订方式</strong></p><p>如您的行程安排有变动，可拨打亲途旅行客服电话（4000-530-586 ）或联系客户专员申请退订。</p><p><strong>退订政策</strong></p><p>如您与亲途旅行网签订服务合同后需要退订行程，因部分行程无法退订，我们会核算、扣除损失后，将剩余款项退还给您。</p><p><strong>退款方式</strong></p><p>我们会以银行转账的方式钱款项退还给您，但需要提供我们您的姓名（与支付时人名一致）、电话、银行账号、银行开户行名称等信息。退款时间为10个工作日之内。</p><p><strong>退款规则</strong></p><p>1. 行程开始前 15天之前全额退还；</p><p>2. 行程开始前 8～14天退还全额的50%；</p><p>3. 行程开始前 7天以内全额将不予退还。</p><p>以上规则适用于部分定制行程，一切最终解释权归亲途所有。</p><p><br/></p>', '退订说明', '', 'publish', 'open', '', '退订说明', '1490874917', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('75', '1', 'c9afa567-4d27-b06e-392b-185e1e967573', '1490880020', '<p>常见问题常见问题</p>', '常见问题', '', 'publish', 'open', '', 'post-question', '1490880020', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('74', '1', 'c88ee252-113e-636b-304c-fc86822b43dd', '1490875155', '<p><strong>联系方式</strong></p><p>日本总部：東京都新宿区西新宿6-10-1</p><p>中国总部：北京市丰台区贾家花园15号院7号楼1层</p><p>邮 &nbsp; &nbsp; &nbsp;编：100070</p><p>客服中心：4000-530-586</p><p>工作时间：9:00-18:00</p><p><strong>商务合作</strong></p><p>联系人：吕经理</p><p>联系方式：15810978446</p><p><br/></p>', '联系我们', '', 'publish', 'open', '', '联系我们', '1490875155', '0', '0', 'post', '0', '0');
INSERT INTO `mini_posts` VALUES ('76', '1', 'd747fe3e-bd6e-8e5b-3b8e-5ad877f2b97f', '1490880089', '<p>费用说明费用说明</p>', '费用说明', '', 'publish', 'open', '', 'post-cost', '1490880089', '0', '0', 'post', '0', '0');

-- -----------------------------
-- Table structure for `mini_term_relationships`
-- -----------------------------
DROP TABLE IF EXISTS `mini_term_relationships`;
CREATE TABLE `mini_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应文章ID/链接ID',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '对应分类方法ID',
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_term_relationships`
-- -----------------------------
INSERT INTO `mini_term_relationships` VALUES ('56', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('57', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('71', '13', '0');
INSERT INTO `mini_term_relationships` VALUES ('70', '13', '0');
INSERT INTO `mini_term_relationships` VALUES ('60', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('63', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('64', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('65', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('66', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('67', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('68', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('72', '13', '0');
INSERT INTO `mini_term_relationships` VALUES ('73', '13', '0');
INSERT INTO `mini_term_relationships` VALUES ('74', '13', '0');
INSERT INTO `mini_term_relationships` VALUES ('75', '12', '0');
INSERT INTO `mini_term_relationships` VALUES ('76', '12', '0');

-- -----------------------------
-- Table structure for `mini_term_taxonomy`
-- -----------------------------
DROP TABLE IF EXISTS `mini_term_taxonomy`;
CREATE TABLE `mini_term_taxonomy` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类方法ID',
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '分类方法(post_tag)',
  `uuid` varchar(128) NOT NULL,
  `taxonomy` varchar(32) NOT NULL DEFAULT '' COMMENT '分类方法(category)',
  `description` longtext NOT NULL,
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '所属父分类方法ID',
  `count` bigint(20) NOT NULL DEFAULT '0' COMMENT '文章数统计',
  PRIMARY KEY (`id`,`count`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_term_taxonomy`
-- -----------------------------
INSERT INTO `mini_term_taxonomy` VALUES ('12', '12', 'a9c77921-19bf-b313-86d4-c5111d36605d', 'category', '', '0', '11');
INSERT INTO `mini_term_taxonomy` VALUES ('13', '13', '0901e3e0-e01e-19d2-9840-b37c09ceaf3b', 'category', '', '0', '5');

-- -----------------------------
-- Table structure for `mini_terms`
-- -----------------------------
DROP TABLE IF EXISTS `mini_terms`;
CREATE TABLE `mini_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(200) NOT NULL DEFAULT '' COMMENT '分类名',
  `slug` varchar(200) NOT NULL DEFAULT '' COMMENT '缩略名',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  `sort` decimal(50,0) NOT NULL COMMENT '用于排序',
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_terms`
-- -----------------------------
INSERT INTO `mini_terms` VALUES ('13', '关于我们', 'about', '0', '0');
INSERT INTO `mini_terms` VALUES ('12', '页面内容', 'page-block', '0', '0');

-- -----------------------------
-- Table structure for `mini_user_extend`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_extend`;
CREATE TABLE `mini_user_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` varchar(300) NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';


-- -----------------------------
-- Table structure for `mini_user_group`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_group`;
CREATE TABLE `mini_user_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为-1禁用',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_user_group`
-- -----------------------------
INSERT INTO `mini_user_group` VALUES ('1', 'admin', '1', '测试用户组', '', '1', '');

-- -----------------------------
-- Table structure for `mini_user_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_group_access`;
CREATE TABLE `mini_user_group_access` (
  `uid` bigint(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_user_rule`
-- -----------------------------
DROP TABLE IF EXISTS `mini_user_rule`;
CREATE TABLE `mini_user_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_users`
-- -----------------------------
DROP TABLE IF EXISTS `mini_users`;
CREATE TABLE `mini_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) NOT NULL COMMENT '系统唯一标识符',
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(64) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(11) NOT NULL,
  `regdate` int(10) NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL DEFAULT '0',
  `salt` varchar(6) NOT NULL DEFAULT '0' COMMENT '加密盐',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1正常，2禁用，-1删除',
  `last_login` int(11) DEFAULT NULL COMMENT '最后登录时间',
  `wechat_openid` varchar(255) DEFAULT NULL COMMENT '微信openid',
  `qq_openid` varchar(255) DEFAULT NULL COMMENT 'qqopenid',
  `sina_openid` varchar(255) NOT NULL COMMENT '微博openid',
  `score` int(11) DEFAULT '0' COMMENT '积分',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE,
  UNIQUE KEY `email` (`email`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mini_users`
-- -----------------------------
INSERT INTO `mini_users` VALUES ('1', 'ad75820a-96c3-a1a8-20c6-195534dd75d3', 'admin', 'e3725a90e473b27068b29205a7f7c2dd', 'admin', 'admin@qq.com', ' ', '1487298736', '1', '071cf9', '1', '1490875386', '', '', '', '0');
INSERT INTO `mini_users` VALUES ('30', '0018d7c7-15f1-58e5-5853-570e1bdfda17', '13810773215', 'bbde9d236d823fee26a48a4d525987ee', '111', '', '13810773215', '1490170291', '0', '3d10f9', '1', '1490331170', '', '', '', '0');
INSERT INTO `mini_users` VALUES ('33', '4090762b-2add-b89f-b3e8-cbe19dd0830d', '11111111112', '72491d9c5f349eba2bf12ac36121c9a7', '111111', '', '11111111112', '1490867841', '0', '13e9de', '1', '', '', '', '', '0');
INSERT INTO `mini_users` VALUES ('34', '839e2cab-1ab8-9c88-65df-e1709fc764b5', 'add1', 'b05aa0145912dfac9299f81c7e66a37f', '111111', '', 'add1', '1490867884', '0', 'c1e78a', '1', '1490867889', '', '', '', '0');
INSERT INTO `mini_users` VALUES ('35', '87f970c8-31c4-cb41-ebb0-03b840539f7b', '13621093997', '71a3725be223407675c67396f8ea2456', '张', '', '13621093997', '1490876452', '0', '49fb3a', '1', '1490885002', '', '', '', '0');
INSERT INTO `mini_users` VALUES ('36', 'b8716529-c45c-51da-5b33-b5307db5b67f', '13621093998', '282e77e17e94a336ae4680e43c51897a', '长', '', '13621093998', '1490885067', '0', 'b9a425', '1', '1490885079', '', '', '', '0');

-- -----------------------------
-- Table structure for `mini_wx_menu`
-- -----------------------------
DROP TABLE IF EXISTS `mini_wx_menu`;
CREATE TABLE `mini_wx_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '菜单名',
  `type` mediumint(2) NOT NULL COMMENT '菜单类型(1跳转，2消息)',
  `url` varchar(225) NOT NULL COMMENT '菜单跳转地址',
  `msg` varchar(1000) NOT NULL COMMENT '回复消息',
  `parent` int(11) NOT NULL DEFAULT '0' COMMENT '父id',
  `key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mini_wx_reply`
-- -----------------------------
DROP TABLE IF EXISTS `mini_wx_reply`;
CREATE TABLE `mini_wx_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` mediumint(2) NOT NULL COMMENT '回复类型，1关注回复2消息回复3关键词回复',
  `key` varchar(225) DEFAULT NULL COMMENT '关键词',
  `msg` varchar(1000) DEFAULT NULL COMMENT '回复内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

